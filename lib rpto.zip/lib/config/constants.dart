import 'package:flutter/material.dart';

// ---------------- Design Tokens (RPTO CDA App) ----------------

const Color kNavy = Color(0xFF050A14);
const Color kTeal = Color(0xFF14B8A6);
const Color kCoral = Color(0xFFFF6B6B);
const Color kAmber = Color(0xFFF59E0B);
const Color kSurface = Color(0xFF0F1B2E);
const Color kGreen = Color(0xFF22C55E);
const Color kPurple = Color(0xFF8B5CF6);

// ---------------- Shared Text Styles ----------------

const TextStyle kTitleStyle = TextStyle(
  color: Colors.white,
  fontSize: 18,
  fontWeight: FontWeight.w600,
);

const TextStyle kSubtitleStyle = TextStyle(
  color: Colors.white54,
  fontSize: 13,
);

const TextStyle kLabelStyle = TextStyle(
  color: Colors.white70,
  fontSize: 13,
  fontWeight: FontWeight.w600,
);

// ---------------- Shared Input Decoration ----------------

InputDecoration kFieldDecoration(String hintOrLabel, {bool isLabel = false}) {
  return InputDecoration(
    hintText: isLabel ? null : hintOrLabel,
    labelText: isLabel ? hintOrLabel : null,
    hintStyle: const TextStyle(color: Colors.white38),
    labelStyle: const TextStyle(color: Colors.white54),
    filled: true,
    fillColor: kSurface,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide.none,
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: Colors.white24),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: kTeal),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: kCoral),
    ),
  );
}

// ---------------- Status Color Helper ----------------

Color kStatusColor(String status) {
  switch (status) {
    case 'Ongoing':
    case 'Active':
    case 'Present':
      return kGreen;
    case 'Upcoming':
      return kAmber;
    case 'Completed':
      return Colors.white38;
    case 'Absent':
    case 'Inactive':
    case 'Dropped':
      return kCoral;
    default:
      return kTeal;
  }
}