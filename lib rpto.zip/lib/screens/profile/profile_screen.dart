import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../../config/theme.dart';
import '../../providers/profile_provider.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isUploading = false;
  bool _darkMode = true;
  bool _pushNotifications = true;
  bool _emailNotifications = true;
  bool _biometricLogin = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProfileProvider>().loadProfile();
    });
  }

  Future<void> _pickAndUploadPhoto(ProfileProvider provider) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
      maxWidth: 800,
    );
    if (picked == null) return;

    setState(() => _isUploading = true);
    final success = await provider.uploadProfilePhoto(File(picked.path));
    setState(() => _isUploading = false);

    if (!success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Upload failed, try again')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ProfileProvider>(
      builder: (context, provider, _) {
        return Scaffold(
          backgroundColor: AppColors.bg,
          body: SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  backgroundColor: AppColors.bg,
                  pinned: true,
                  title: const Text(
                    'Profile',
                    style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w800),
                  ),
                  iconTheme: const IconThemeData(color: AppColors.textPrimary),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildPhotoSection(provider),
                        const SizedBox(height: 28),
                        _sectionLabel('ACCOUNT', Icons.person_outline),
                        const SizedBox(height: 10),
                        _sectionCard([
                          _tile(
                            icon: Icons.lock_outline,
                            iconColor: AppColors.blue,
                            title: 'Change Password',
                            subtitle: 'Sends a reset link to your email',
                            onTap: () {
                              // TODO: trigger password reset flow
                            },
                          ),
                          _tile(
                            icon: Icons.fingerprint,
                            iconColor: AppColors.blue,
                            title: 'Biometric Login',
                            subtitle: 'Use fingerprint / face unlock',
                            trailing: Switch(
                              value: _biometricLogin,
                              activeColor: AppColors.teal,
                              onChanged: (val) => setState(() => _biometricLogin = val),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 22),
                        _sectionLabel('NOTIFICATIONS', Icons.notifications_none),
                        const SizedBox(height: 10),
                        _sectionCard([
                          _tile(
                            icon: Icons.campaign_outlined,
                            iconColor: AppColors.purple,
                            title: 'Push Notifications',
                            subtitle: 'Stock alerts & drone activity',
                            trailing: Switch(
                              value: _pushNotifications,
                              activeColor: AppColors.teal,
                              onChanged: (val) => setState(() => _pushNotifications = val),
                            ),
                          ),
                          _tile(
                            icon: Icons.mail_outline,
                            iconColor: AppColors.purple,
                            title: 'Email Notifications',
                            subtitle: 'Weekly inventory reports',
                            trailing: Switch(
                              value: _emailNotifications,
                              activeColor: AppColors.teal,
                              onChanged: (val) => setState(() => _emailNotifications = val),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 22),
                        _sectionLabel('PREFERENCES', Icons.tune),
                        const SizedBox(height: 10),
                        _sectionCard([
                          _tile(
                            icon: Icons.dark_mode_outlined,
                            iconColor: AppColors.teal,
                            title: 'Dark Mode',
                            subtitle: 'Navy theme (recommended)',
                            trailing: Switch(
                              value: _darkMode,
                              activeColor: AppColors.teal,
                              onChanged: (val) => setState(() => _darkMode = val),
                            ),
                          ),
                          _tile(
                            icon: Icons.language,
                            iconColor: AppColors.teal,
                            title: 'Language',
                            subtitle: 'English (India)',
                            onTap: () {
                              // TODO: open language picker
                            },
                          ),
                        ]),
                        const SizedBox(height: 22),
                        _sectionLabel('SUPPORT', Icons.help_outline),
                        const SizedBox(height: 10),
                        _sectionCard([
                          _tile(
                            icon: Icons.support_agent,
                            iconColor: AppColors.amber,
                            title: 'Help & Support',
                            subtitle: 'Contact the CDA IT team',
                            onTap: () {
                              // TODO: open support contact
                            },
                          ),
                          _tile(
                            icon: Icons.info_outline,
                            iconColor: AppColors.amber,
                            title: 'About App',
                            subtitle: 'RPTO Management v1.0',
                            onTap: () {
                              // TODO: show about dialog
                            },
                          ),
                        ]),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPhotoSection(ProfileProvider provider) {
    return Center(
      child: Column(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 45,
                backgroundColor: AppColors.surface,
                backgroundImage: provider.photoUrl != null
                    ? NetworkImage(provider.photoUrl!)
                    : null,
                child: provider.photoUrl == null
                    ? const Icon(Icons.person, size: 45, color: AppColors.textSecondary)
                    : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: _isUploading ? null : () => _pickAndUploadPhoto(provider),
                  child: CircleAvatar(
                    radius: 15,
                    backgroundColor: AppColors.teal,
                    child: _isUploading
                        ? const SizedBox(
                      width: 13,
                      height: 13,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                    )
                        : const Icon(Icons.camera_alt, size: 15, color: Colors.black),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            provider.name ?? 'Loading...',
            style: const TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
          ),
          if (provider.email != null) ...[
            const SizedBox(height: 3),
            Text(
              provider.email!,
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
          ],
        ],
      ),
    );
  }

  Widget _sectionLabel(String label, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 14, color: AppColors.textSecondary),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
            color: AppColors.textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.1,
          ),
        ),
      ],
    );
  }

  Widget _sectionCard(List<Widget> tiles) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          for (int i = 0; i < tiles.length; i++) ...[
            tiles[i],
            if (i != tiles.length - 1) const Divider(color: AppColors.border, height: 1),
          ],
        ],
      ),
    );
  }

  Widget _tile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: iconColor.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor, size: 19),
      ),
      title: Text(
        title,
        style: const TextStyle(color: AppColors.textPrimary, fontSize: 14.5, fontWeight: FontWeight.w700),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
      ),
      trailing: trailing ?? const Icon(Icons.chevron_right, color: AppColors.textSecondary, size: 20),
    );
  }
}