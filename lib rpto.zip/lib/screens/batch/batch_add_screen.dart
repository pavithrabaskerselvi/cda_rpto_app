import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

// ---------- Design Constants (match BatchListScreen / existing design system) ----------
const Color _kNavy = Color(0xFF0A0E1A);
const Color _kSurface = Color(0xFF131826);
const Color _kTeal = Color(0xFF14B8A6);
const Color _kTextSecondary = Color(0xFF9CA3AF);
const Color _kBorder = Color(0xFF1F2937);

class AddBatchScreen extends StatefulWidget {
  const AddBatchScreen({super.key});

  @override
  State<AddBatchScreen> createState() => _AddBatchScreenState();
}

class _AddBatchScreenState extends State<AddBatchScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _batchNameController = TextEditingController();
  final TextEditingController _studentCountController =
  TextEditingController();

  String? _selectedInstructor;
  String _selectedStatus = 'Upcoming';
  DateTime? _startDate;
  DateTime? _endDate;

  bool _isSaving = false;

  final List<String> _statusOptions = ['Upcoming', 'Ongoing', 'Completed'];

  @override
  void dispose() {
    _batchNameController.dispose();
    _studentCountController.dispose();
    super.dispose();
  }

  Future<void> _pickDate({required bool isStart}) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart
          ? (_startDate ?? now)
          : (_endDate ?? _startDate ?? now),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 3),
      builder: (context, child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: const ColorScheme.dark(
              primary: _kTeal,
              surface: _kSurface,
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: _kNavy,
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          // reset end date if it's before new start date
          if (_endDate != null && _endDate!.isBefore(_startDate!)) {
            _endDate = null;
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Select date';
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  Future<void> _saveBatch() async {
    if (!_formKey.currentState!.validate()) return;

    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select start and end dates'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    if (_selectedInstructor == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select an instructor'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() => _isSaving = true);

    try {
      await FirebaseFirestore.instance.collection('batches').add({
        'batchName': _batchNameController.text.trim(),
        'instructor': _selectedInstructor,
        'studentCount': int.tryParse(_studentCountController.text.trim()) ?? 0,
        'status': _selectedStatus,
        'startDate': Timestamp.fromDate(_startDate!),
        'endDate': Timestamp.fromDate(_endDate!),
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Batch created successfully'),
            backgroundColor: _kTeal,
          ),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving batch: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  InputDecoration _inputDecoration(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: _kTextSecondary),
      prefixIcon: icon != null ? Icon(icon, color: _kTextSecondary) : null,
      filled: true,
      fillColor: _kSurface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kTeal, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kNavy,
      appBar: AppBar(
        backgroundColor: _kNavy,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Add Batch',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _batchNameController,
              style: const TextStyle(color: Colors.white),
              decoration: _inputDecoration('Batch Name', icon: Icons.badge_outlined),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Batch name is required';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            // Instructor dropdown - pulled from Firestore 'instructors' collection
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('instructors')
                  .orderBy('name')
                  .snapshots(),
              builder: (context, snapshot) {
                final instructorNames = <String>[];
                if (snapshot.hasData) {
                  for (final doc in snapshot.data!.docs) {
                    final data = doc.data() as Map<String, dynamic>;
                    final name = data['name'];
                    if (name != null) instructorNames.add(name.toString());
                  }
                }

                return DropdownButtonFormField<String>(
                  value: _selectedInstructor,
                  dropdownColor: _kSurface,
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDecoration('Instructor', icon: Icons.person_outline),
                  items: instructorNames
                      .map((name) => DropdownMenuItem(
                    value: name,
                    child: Text(name),
                  ))
                      .toList(),
                  onChanged: (value) {
                    setState(() => _selectedInstructor = value);
                  },
                  validator: (value) =>
                  value == null ? 'Please select an instructor' : null,
                );
              },
            ),
            const SizedBox(height: 16),

            TextFormField(
              controller: _studentCountController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: _inputDecoration('Number of Students', icon: Icons.groups_2_outlined),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Student count is required';
                }
                if (int.tryParse(value.trim()) == null) {
                  return 'Enter a valid number';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            DropdownButtonFormField<String>(
              value: _selectedStatus,
              dropdownColor: _kSurface,
              style: const TextStyle(color: Colors.white),
              decoration: _inputDecoration('Status', icon: Icons.flag_outlined),
              items: _statusOptions
                  .map((status) => DropdownMenuItem(
                value: status,
                child: Text(status),
              ))
                  .toList(),
              onChanged: (value) {
                setState(() => _selectedStatus = value ?? 'Upcoming');
              },
            ),
            const SizedBox(height: 16),

            // Start Date
            InkWell(
              onTap: () => _pickDate(isStart: true),
              borderRadius: BorderRadius.circular(12),
              child: InputDecorator(
                decoration: _inputDecoration('Start Date', icon: Icons.calendar_today_outlined),
                child: Text(
                  _formatDate(_startDate),
                  style: TextStyle(
                    color: _startDate == null ? _kTextSecondary : Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // End Date
            InkWell(
              onTap: () => _pickDate(isStart: false),
              borderRadius: BorderRadius.circular(12),
              child: InputDecorator(
                decoration: _inputDecoration('End Date', icon: Icons.calendar_today_outlined),
                child: Text(
                  _formatDate(_endDate),
                  style: TextStyle(
                    color: _endDate == null ? _kTextSecondary : Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),

            SizedBox(
              height: 52,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _saveBatch,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kTeal,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isSaving
                    ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                )
                    : const Text(
                  'Save Batch',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}