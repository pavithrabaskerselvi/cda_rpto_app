import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

// ---------- Design Constants (match BatchListScreen / AddBatchScreen) ----------
const Color _kNavy = Color(0xFF0A0E1A);
const Color _kSurface = Color(0xFF131826);
const Color _kTeal = Color(0xFF14B8A6);
const Color _kTextSecondary = Color(0xFF9CA3AF);
const Color _kBorder = Color(0xFF1F2937);

class BatchDetailScreen extends StatefulWidget {
  final String batchId;

  const BatchDetailScreen({super.key, required this.batchId});

  @override
  State<BatchDetailScreen> createState() => _BatchDetailScreenState();
}

class _BatchDetailScreenState extends State<BatchDetailScreen> {
  final _formKey = GlobalKey<FormState>();

  bool _isEditing = false;
  bool _isSaving = false;
  bool _isDeleting = false;

  late TextEditingController _batchNameController;
  late TextEditingController _studentCountController;

  String? _selectedInstructor;
  String? _selectedDrone;
  String _selectedStatus = 'Upcoming';
  DateTime? _startDate;
  DateTime? _endDate;

  bool _initialized = false;

  final List<String> _statusOptions = ['Upcoming', 'Ongoing', 'Completed'];

  @override
  void initState() {
    super.initState();
    _batchNameController = TextEditingController();
    _studentCountController = TextEditingController();
  }

  @override
  void dispose() {
    _batchNameController.dispose();
    _studentCountController.dispose();
    super.dispose();
  }

  void _populateFields(Map<String, dynamic> data) {
    if (_initialized) return;
    _batchNameController.text = data['batchName'] ?? '';
    _studentCountController.text = (data['studentCount'] ?? '').toString();
    _selectedInstructor = data['instructor'];
    _selectedDrone = data['drone'];
    _selectedStatus = data['status'] ?? 'Upcoming';
    _startDate = data['startDate'] != null
        ? (data['startDate'] as Timestamp).toDate()
        : null;
    _endDate = data['endDate'] != null
        ? (data['endDate'] as Timestamp).toDate()
        : null;
    _initialized = true;
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'ongoing':
        return _kTeal;
      case 'completed':
        return Colors.greenAccent;
      case 'upcoming':
        return Colors.amberAccent;
      default:
        return _kTextSecondary;
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Select date';
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  Future<void> _pickDate({required bool isStart}) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart ? (_startDate ?? now) : (_endDate ?? _startDate ?? now),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 3),
      builder: (context, child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: const ColorScheme.dark(
              primary: _kTeal,
              surface: _kSurface,
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: _kNavy,
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          if (_endDate != null && _endDate!.isBefore(_startDate!)) {
            _endDate = null;
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  Future<void> _saveChanges() async {
    if (!_formKey.currentState!.validate()) return;

    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select start and end dates'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() => _isSaving = true);

    try {
      await FirebaseFirestore.instance
          .collection('batches')
          .doc(widget.batchId)
          .update({
        'batchName': _batchNameController.text.trim(),
        'instructor': _selectedInstructor,
        'drone': _selectedDrone,
        'studentCount': int.tryParse(_studentCountController.text.trim()) ?? 0,
        'status': _selectedStatus,
        'startDate': Timestamp.fromDate(_startDate!),
        'endDate': Timestamp.fromDate(_endDate!),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        setState(() => _isEditing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Batch updated successfully'),
            backgroundColor: _kTeal,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating batch: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _confirmDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _kSurface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('Delete Batch', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to delete this batch? This action cannot be undone.',
          style: TextStyle(color: _kTextSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel', style: TextStyle(color: _kTextSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isDeleting = true);
      try {
        await FirebaseFirestore.instance
            .collection('batches')
            .doc(widget.batchId)
            .delete();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Batch deleted'),
              backgroundColor: _kTeal,
            ),
          );
          Navigator.of(context).pop();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error deleting batch: $e'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
        setState(() => _isDeleting = false);
      }
    }
  }

  InputDecoration _inputDecoration(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: _kTextSecondary),
      prefixIcon: icon != null ? Icon(icon, color: _kTextSecondary) : null,
      filled: true,
      fillColor: _kSurface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kTeal, width: 1.5),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _kBorder),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kNavy,
      appBar: AppBar(
        backgroundColor: _kNavy,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Batch Details',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20),
        ),
        actions: [
          if (!_isEditing)
            IconButton(
              icon: const Icon(Icons.edit_outlined, color: _kTeal),
              onPressed: () => setState(() => _isEditing = true),
            ),
          IconButton(
            icon: _isDeleting
                ? const SizedBox(
              height: 18,
              width: 18,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.redAccent),
            )
                : const Icon(Icons.delete_outline, color: Colors.redAccent),
            onPressed: _isDeleting ? null : _confirmDelete,
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('batches')
            .doc(widget.batchId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading batch: ${snapshot.error}',
                style: const TextStyle(color: Colors.redAccent),
              ),
            );
          }

          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator(color: _kTeal));
          }

          if (!snapshot.data!.exists) {
            return const Center(
              child: Text('Batch not found', style: TextStyle(color: _kTextSecondary)),
            );
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          _populateFields(data);

          return Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _statusColor(_selectedStatus).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.circle, size: 8, color: _statusColor(_selectedStatus)),
                      const SizedBox(width: 6),
                      Text(
                        _selectedStatus,
                        style: TextStyle(
                          color: _statusColor(_selectedStatus),
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                TextFormField(
                  controller: _batchNameController,
                  enabled: _isEditing,
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDecoration('Batch Name', icon: Icons.badge_outlined),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Batch name is required';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                _isEditing
                    ? StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('instructors')
                      .orderBy('name')
                      .snapshots(),
                  builder: (context, snap) {
                    final names = <String>[];
                    if (snap.hasData) {
                      for (final doc in snap.data!.docs) {
                        final d = doc.data() as Map<String, dynamic>;
                        if (d['name'] != null) names.add(d['name'].toString());
                      }
                    }
                    if (_selectedInstructor != null &&
                        !names.contains(_selectedInstructor)) {
                      names.add(_selectedInstructor!);
                    }
                    return DropdownButtonFormField<String>(
                      value: _selectedInstructor,
                      dropdownColor: _kSurface,
                      style: const TextStyle(color: Colors.white),
                      decoration:
                      _inputDecoration('Instructor', icon: Icons.person_outline),
                      items: names
                          .map((n) => DropdownMenuItem(value: n, child: Text(n)))
                          .toList(),
                      onChanged: (v) => setState(() => _selectedInstructor = v),
                      validator: (v) => v == null ? 'Please select an instructor' : null,
                    );
                  },
                )
                    : TextFormField(
                  enabled: false,
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDecoration('Instructor', icon: Icons.person_outline)
                      .copyWith(hintText: _selectedInstructor),
                  controller: TextEditingController(text: _selectedInstructor ?? '-'),
                ),
                const SizedBox(height: 16),

                _isEditing
                    ? StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('drones')
                      .orderBy('name')
                      .snapshots(),
                  builder: (context, snap) {
                    final names = <String>[];
                    if (snap.hasData) {
                      for (final doc in snap.data!.docs) {
                        final d = doc.data() as Map<String, dynamic>;
                        if (d['name'] != null) names.add(d['name'].toString());
                      }
                    }
                    if (_selectedDrone != null && !names.contains(_selectedDrone)) {
                      names.add(_selectedDrone!);
                    }
                    return DropdownButtonFormField<String>(
                      value: _selectedDrone,
                      dropdownColor: _kSurface,
                      style: const TextStyle(color: Colors.white),
                      decoration: _inputDecoration('Drone', icon: Icons.flight_outlined),
                      items: names
                          .map((n) => DropdownMenuItem(value: n, child: Text(n)))
                          .toList(),
                      onChanged: (v) => setState(() => _selectedDrone = v),
                      validator: (v) => v == null ? 'Please select a drone' : null,
                    );
                  },
                )
                    : TextFormField(
                  enabled: false,
                  style: const TextStyle(color: Colors.white),
                  controller: TextEditingController(text: _selectedDrone ?? '-'),
                  decoration: _inputDecoration('Drone', icon: Icons.flight_outlined),
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _studentCountController,
                  enabled: _isEditing,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.white),
                  decoration:
                  _inputDecoration('Number of Students', icon: Icons.groups_2_outlined),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Student count is required';
                    }
                    if (int.tryParse(value.trim()) == null) {
                      return 'Enter a valid number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                _isEditing
                    ? DropdownButtonFormField<String>(
                  value: _selectedStatus,
                  dropdownColor: _kSurface,
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDecoration('Status', icon: Icons.flag_outlined),
                  items: _statusOptions
                      .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedStatus = v ?? 'Upcoming'),
                )
                    : const SizedBox.shrink(),
                if (_isEditing) const SizedBox(height: 16),

                InkWell(
                  onTap: _isEditing ? () => _pickDate(isStart: true) : null,
                  borderRadius: BorderRadius.circular(12),
                  child: InputDecorator(
                    decoration: _inputDecoration('Start Date', icon: Icons.calendar_today_outlined),
                    child: Text(
                      _formatDate(_startDate),
                      style: TextStyle(
                        color: _isEditing ? Colors.white : _kTextSecondary,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                InkWell(
                  onTap: _isEditing ? () => _pickDate(isStart: false) : null,
                  borderRadius: BorderRadius.circular(12),
                  child: InputDecorator(
                    decoration: _inputDecoration('End Date', icon: Icons.calendar_today_outlined),
                    child: Text(
                      _formatDate(_endDate),
                      style: TextStyle(
                        color: _isEditing ? Colors.white : _kTextSecondary,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 32),

                if (_isEditing)
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _isSaving
                              ? null
                              : () {
                            setState(() {
                              _isEditing = false;
                              _initialized = false;
                              _populateFields(data);
                            });
                          },
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: _kBorder),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text('Cancel',
                              style: TextStyle(color: _kTextSecondary)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _isSaving ? null : _saveChanges,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kTeal,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: _isSaving
                              ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          )
                              : const Text(
                            'Save Changes',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}