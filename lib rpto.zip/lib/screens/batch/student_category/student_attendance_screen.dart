import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../../models/student_model.dart';

// Design tokens
const Color kNavy = Color(0xFF050A14);
const Color kTeal = Color(0xFF14B8A6);
const Color kCoral = Color(0xFFFF6B6B);
const Color kAmber = Color(0xFFF59E0B);
const Color kSurface = Color(0xFF0F1B2E);
const Color kGreen = Color(0xFF22C55E);
const Color kPurple = Color(0xFF8B5CF6);

class StudentAttendanceScreen extends StatefulWidget {
  final StudentModel student;

  const StudentAttendanceScreen({super.key, required this.student});

  @override
  State<StudentAttendanceScreen> createState() => _StudentAttendanceScreenState();
}

class _StudentAttendanceScreenState extends State<StudentAttendanceScreen> {
  bool _isLoading = true;
  List<Map<String, dynamic>> _attendanceRecords = []; // {date, present}
  int _presentCount = 0;
  int _totalCount = 0;

  @override
  void initState() {
    super.initState();
    _loadAttendanceHistory();
  }

  Future<void> _loadAttendanceHistory() async {
    setState(() => _isLoading = true);
    try {
      final snap = await FirebaseFirestore.instance
          .collection('attendance')
          .where('batchId', isEqualTo: widget.student.batchId)
          .orderBy('date', descending: true)
          .get();

      List<Map<String, dynamic>> records = [];
      int present = 0;
      int total = 0;

      for (var doc in snap.docs) {
        final data = doc.data();
        final recordsMap = data['records'] as Map<String, dynamic>? ?? {};

        if (recordsMap.containsKey(widget.student.id)) {
          final isPresent = recordsMap[widget.student.id] as bool;
          final date = (data['date'] as Timestamp).toDate();

          records.add({'date': date, 'present': isPresent});
          total++;
          if (isPresent) present++;
        }
      }

      setState(() {
        _attendanceRecords = records;
        _presentCount = present;
        _totalCount = total;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load: $e'), backgroundColor: kCoral),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final percentage = _totalCount == 0 ? 0.0 : (_presentCount / _totalCount) * 100;
    final percentColor = percentage >= 75 ? kGreen : (percentage >= 50 ? kAmber : kCoral);

    return Scaffold(
      backgroundColor: kNavy,
      appBar: AppBar(
        backgroundColor: kNavy,
        title: Text(widget.student.name, style: const TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: kTeal))
          : Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: percentColor.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 70,
                  height: 70,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CircularProgressIndicator(
                        value: _totalCount == 0 ? 0 : _presentCount / _totalCount,
                        strokeWidth: 6,
                        backgroundColor: Colors.white12,
                        valueColor: AlwaysStoppedAnimation(percentColor),
                      ),
                      Text(
                        '${percentage.toStringAsFixed(0)}%',
                        style: TextStyle(color: percentColor, fontWeight: FontWeight.w700, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Attendance Summary',
                          style: TextStyle(color: Colors.white54, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(
                        '$_presentCount / $_totalCount days present',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${_totalCount - _presentCount} days absent',
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _attendanceRecords.isEmpty
                ? const Center(
              child: Text('No attendance records found',
                  style: TextStyle(color: Colors.white54)),
            )
                : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _attendanceRecords.length,
              itemBuilder: (context, index) {
                final record = _attendanceRecords[index];
                final date = record['date'] as DateTime;
                final present = record['present'] as bool;

                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: kSurface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: present ? kGreen.withOpacity(0.3) : kCoral.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        present ? Icons.check_circle : Icons.cancel,
                        color: present ? kGreen : kCoral,
                        size: 20,
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '${date.day}/${date.month}/${date.year}',
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                      ),
                      const Spacer(),
                      Text(
                        present ? 'Present' : 'Absent',
                        style: TextStyle(
                          color: present ? kGreen : kCoral,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
