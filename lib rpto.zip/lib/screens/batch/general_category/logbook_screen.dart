import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../../models/student_model.dart';
import '../../../models/drone_model.dart';

// Design tokens
const Color kNavy = Color(0xFF050A14);
const Color kTeal = Color(0xFF14B8A6);
const Color kCoral = Color(0xFFFF6B6B);
const Color kAmber = Color(0xFFF59E0B);
const Color kSurface = Color(0xFF0F1B2E);
const Color kGreen = Color(0xFF22C55E);
const Color kPurple = Color(0xFF8B5CF6);

class LogbookScreen extends StatefulWidget {
  final String batchId;
  final String batchName;

  const LogbookScreen({
    super.key,
    required this.batchId,
    required this.batchName,
  });

  @override
  State<LogbookScreen> createState() => _LogbookScreenState();
}

class _LogbookScreenState extends State<LogbookScreen> {
  bool _isLoading = true;
  List<StudentModel> _students = [];

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  Future<void> _loadStudents() async {
    setState(() => _isLoading = true);
    try {
      final snap = await FirebaseFirestore.instance
          .collection('students')
          .where('batchId', isEqualTo: widget.batchId)
          .get();
      setState(() {
        _students = snap.docs.map((d) => StudentModel.fromDocument(d)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load: $e'), backgroundColor: kCoral),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: kNavy,
            pinned: true,
            expandedHeight: 130,
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              title: Text(
                '${widget.batchName} - Flight Logbook',
                style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600),
              ),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [kAmber.withOpacity(0.25), kNavy],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          if (_isLoading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: kTeal)),
            )
          else if (_students.isEmpty)
            const SliverFillRemaining(
              child: Center(
                child: Text('No students found in this batch', style: TextStyle(color: Colors.white54)),
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) => _buildStudentTile(_students[index]),
                childCount: _students.length,
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }

  Widget _buildStudentTile(StudentModel student) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => StudentLogbookScreen(student: student),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.06)),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: kAmber.withOpacity(0.2),
              child: Text(
                student.name.isNotEmpty ? student.name[0].toUpperCase() : '?',
                style: const TextStyle(color: kAmber, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(student.name,
                      style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(student.phone, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white38),
          ],
        ),
      ),
    );
  }
}

// ---------------- Student Logbook Entries ----------------

class StudentLogbookScreen extends StatefulWidget {
  final StudentModel student;

  const StudentLogbookScreen({super.key, required this.student});

  @override
  State<StudentLogbookScreen> createState() => _StudentLogbookScreenState();
}

class _StudentLogbookScreenState extends State<StudentLogbookScreen> {
  bool _isSaving = false;
  List<DroneModel> _drones = [];

  @override
  void initState() {
    super.initState();
    _loadDrones();
  }

  Future<void> _loadDrones() async {
    try {
      final snap = await FirebaseFirestore.instance.collection('drones').get();
      setState(() {
        _drones = snap.docs.map((d) => DroneModel.fromDocument(d)).toList();
      });
    } catch (_) {}
  }

  Stream<QuerySnapshot> _logEntriesStream() {
    return FirebaseFirestore.instance
        .collection('logbook_entries')
        .where('studentId', isEqualTo: widget.student.id)
        .orderBy('flightDate', descending: true)
        .snapshots();
  }

  Future<void> _addEntryDialog() async {
    DateTime flightDate = DateTime.now();
    String? selectedDroneId;
    String? selectedDroneName;
    final sortieController = TextEditingController();
    final durationController = TextEditingController();
    final remarksController = TextEditingController();
    String flightType = 'Solo';

    await showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('New Logbook Entry',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 16),
                    InkWell(
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: flightDate,
                          firstDate: DateTime(2023),
                          lastDate: DateTime.now(),
                          builder: (context, child) => Theme(
                            data: Theme.of(context).copyWith(
                              colorScheme: ColorScheme.dark(primary: kTeal, surface: kSurface),
                            ),
                            child: child!,
                          ),
                        );
                        if (picked != null) setModalState(() => flightDate = picked);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.calendar_today, color: Colors.white54, size: 18),
                            const SizedBox(width: 10),
                            Text('${flightDate.day}/${flightDate.month}/${flightDate.year}',
                                style: const TextStyle(color: Colors.white)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedDroneId,
                      dropdownColor: kSurface,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration('Select Drone'),
                      items: _drones
                          .map((d) => DropdownMenuItem(
                        value: d.id,
                        child: Text(d.droneName, style: const TextStyle(color: Colors.white)),
                      ))
                          .toList(),
                      onChanged: (val) {
                        setModalState(() {
                          selectedDroneId = val;
                          selectedDroneName = _drones.firstWhere((d) => d.id == val).droneName;
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: flightType,
                      dropdownColor: kSurface,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration('Flight Type'),
                      items: ['Solo', 'Dual', 'Simulator']
                          .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                          .toList(),
                      onChanged: (val) => setModalState(() => flightType = val ?? 'Solo'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: sortieController,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration('Sortie Type (e.g. Take-off/Landing)'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: durationController,
                      keyboardType: TextInputType.number,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration('Duration (minutes)'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: remarksController,
                      maxLines: 3,
                      style: const TextStyle(color: Colors.white),
                      decoration: _fieldDecoration('Remarks'),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: _isSaving
                            ? null
                            : () async {
                          if (selectedDroneId == null ||
                              sortieController.text.trim().isEmpty ||
                              durationController.text.trim().isEmpty) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Fill all required fields'), backgroundColor: kCoral),
                            );
                            return;
                          }
                          setState(() => _isSaving = true);
                          try {
                            await FirebaseFirestore.instance.collection('logbook_entries').add({
                              'studentId': widget.student.id,
                              'studentName': widget.student.name,
                              'batchId': widget.student.batchId,
                              'droneId': selectedDroneId,
                              'droneName': selectedDroneName,
                              'flightDate': Timestamp.fromDate(flightDate),
                              'flightType': flightType,
                              'sortieType': sortieController.text.trim(),
                              'durationMinutes': int.tryParse(durationController.text.trim()) ?? 0,
                              'remarks': remarksController.text.trim(),
                              'createdAt': FieldValue.serverTimestamp(),
                            });
                            if (mounted) {
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Logbook entry saved'), backgroundColor: kGreen),
                              );
                            }
                          } catch (e) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Error: $e'), backgroundColor: kCoral),
                              );
                            }
                          } finally {
                            setState(() => _isSaving = false);
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kTeal,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: _isSaving
                            ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                            : const Text('Save Entry',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  InputDecoration _fieldDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white54),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Colors.white24),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kTeal),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      appBar: AppBar(
        backgroundColor: kNavy,
        title: Text(widget.student.name, style: const TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kTeal,
        onPressed: _addEntryDialog,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _logEntriesStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: kTeal));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text('No logbook entries yet', style: TextStyle(color: Colors.white54)),
            );
          }
          final docs = snapshot.data!.docs;

          final totalMinutes = docs.fold<int>(0, (sum, doc) {
            final data = doc.data() as Map<String, dynamic>;
            return sum + ((data['durationMinutes'] ?? 0) as int);
          });

          return Column(
            children: [
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kSurface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: kAmber.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.timer, color: kAmber),
                    const SizedBox(width: 10),
                    Text(
                      'Total Flight Time: ${totalMinutes ~/ 60}h ${totalMinutes % 60}m',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                    const Spacer(),
                    Text('${docs.length} entries', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data() as Map<String, dynamic>;
                    final date = (data['flightDate'] as Timestamp).toDate();

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: kSurface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white.withOpacity(0.06)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  data['droneName'] ?? '',
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                                ),
                              ),
                              Text('${date.day}/${date.month}/${date.year}',
                                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Wrap(
                            spacing: 8,
                            children: [
                              _buildChip(data['flightType'] ?? '', kPurple),
                              _buildChip('${data['durationMinutes'] ?? 0} min', kTeal),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text('Sortie: ${data['sortieType'] ?? ''}',
                              style: const TextStyle(color: Colors.white70, fontSize: 13)),
                          if ((data['remarks'] ?? '').toString().isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(data['remarks'],
                                style: const TextStyle(color: Colors.white54, fontSize: 12)),
                          ],
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }
}