import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../../models/student_model.dart';

// Design tokens
const Color kNavy = Color(0xFF050A14);
const Color kTeal = Color(0xFF14B8A6);
const Color kCoral = Color(0xFFFF6B6B);
const Color kAmber = Color(0xFFF59E0B);
const Color kSurface = Color(0xFF0F1B2E);
const Color kGreen = Color(0xFF22C55E);
const Color kPurple = Color(0xFF8B5CF6);

class CounselingScreen extends StatefulWidget {
  final String batchId;
  final String batchName;

  const CounselingScreen({
    super.key,
    required this.batchId,
    required this.batchName,
  });

  @override
  State<CounselingScreen> createState() => _CounselingScreenState();
}

class _CounselingScreenState extends State<CounselingScreen> {
  bool _isLoading = true;
  List<StudentModel> _students = [];

  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  Future<void> _loadStudents() async {
    setState(() => _isLoading = true);
    try {
      final snap = await FirebaseFirestore.instance
          .collection('students')
          .where('batchId', isEqualTo: widget.batchId)
          .get();
      setState(() {
        _students = snap.docs.map((d) => StudentModel.fromDocument(d)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load: $e'), backgroundColor: kCoral),
        );
      }
    }
  }

  void _openStudentSessions(StudentModel student) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StudentCounselingSessionsScreen(student: student),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: kNavy,
            pinned: true,
            expandedHeight: 130,
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              title: Text(
                '${widget.batchName} - Counseling',
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
              ),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [kPurple.withOpacity(0.25), kNavy],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          if (_isLoading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: kTeal)),
            )
          else if (_students.isEmpty)
            const SliverFillRemaining(
              child: Center(
                child: Text('No students found in this batch', style: TextStyle(color: Colors.white54)),
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  final student = _students[index];
                  return _buildStudentTile(student);
                },
                childCount: _students.length,
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }

  Widget _buildStudentTile(StudentModel student) {
    return InkWell(
      onTap: () => _openStudentSessions(student),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.06)),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: kPurple.withOpacity(0.2),
              child: Text(
                student.name.isNotEmpty ? student.name[0].toUpperCase() : '?',
                style: const TextStyle(color: kPurple, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(student.name,
                      style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(student.phone, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white38),
          ],
        ),
      ),
    );
  }
}

// ---------------- Student Counseling Sessions ----------------

class StudentCounselingSessionsScreen extends StatefulWidget {
  final StudentModel student;

  const StudentCounselingSessionsScreen({super.key, required this.student});

  @override
  State<StudentCounselingSessionsScreen> createState() =>
      _StudentCounselingSessionsScreenState();
}

class _StudentCounselingSessionsScreenState
    extends State<StudentCounselingSessionsScreen> {
  bool _isSaving = false;

  Stream<QuerySnapshot> _sessionsStream() {
    return FirebaseFirestore.instance
        .collection('counseling_sessions')
        .where('studentId', isEqualTo: widget.student.id)
        .orderBy('sessionDate', descending: true)
        .snapshots();
  }

  Future<void> _addSessionDialog() async {
    final notesController = TextEditingController();
    final counselorController = TextEditingController();
    DateTime sessionDate = DateTime.now();
    bool followUpRequired = false;

    await showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('New Counseling Session',
                      style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: counselorController,
                    style: const TextStyle(color: Colors.white),
                    decoration: _fieldDecoration('Counselor Name'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: notesController,
                    maxLines: 4,
                    style: const TextStyle(color: Colors.white),
                    decoration: _fieldDecoration('Session Notes / Remarks'),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: sessionDate,
                        firstDate: DateTime(2023),
                        lastDate: DateTime.now(),
                        builder: (context, child) => Theme(
                          data: Theme.of(context).copyWith(
                            colorScheme: ColorScheme.dark(primary: kTeal, surface: kSurface),
                          ),
                          child: child!,
                        ),
                      );
                      if (picked != null) {
                        setModalState(() => sessionDate = picked);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white24),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.calendar_today, color: Colors.white54, size: 18),
                          const SizedBox(width: 10),
                          Text(
                            '${sessionDate.day}/${sessionDate.month}/${sessionDate.year}',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Checkbox(
                        value: followUpRequired,
                        activeColor: kAmber,
                        onChanged: (val) => setModalState(() => followUpRequired = val ?? false),
                      ),
                      const Text('Follow-up required', style: TextStyle(color: Colors.white70)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _isSaving
                          ? null
                          : () async {
                        if (counselorController.text.trim().isEmpty ||
                            notesController.text.trim().isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Fill all fields'), backgroundColor: kCoral),
                          );
                          return;
                        }
                        setState(() => _isSaving = true);
                        try {
                          await FirebaseFirestore.instance.collection('counseling_sessions').add({
                            'studentId': widget.student.id,
                            'studentName': widget.student.name,
                            'batchId': widget.student.batchId,
                            'counselorName': counselorController.text.trim(),
                            'notes': notesController.text.trim(),
                            'sessionDate': Timestamp.fromDate(sessionDate),
                            'followUpRequired': followUpRequired,
                            'createdAt': FieldValue.serverTimestamp(),
                          });
                          if (mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Session saved'), backgroundColor: kGreen),
                            );
                          }
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Error: $e'), backgroundColor: kCoral),
                            );
                          }
                        } finally {
                          setState(() => _isSaving = false);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kTeal,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: _isSaving
                          ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      )
                          : const Text('Save Session',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  InputDecoration _fieldDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white54),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: Colors.white24),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: kTeal),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      appBar: AppBar(
        backgroundColor: kNavy,
        title: Text(widget.student.name, style: const TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kTeal,
        onPressed: _addSessionDialog,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _sessionsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: kTeal));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text('No counseling sessions yet', style: TextStyle(color: Colors.white54)),
            );
          }
          final docs = snapshot.data!.docs;
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              final date = (data['sessionDate'] as Timestamp).toDate();
              final followUp = data['followUpRequired'] ?? false;

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: kSurface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: followUp ? kAmber.withOpacity(0.4) : Colors.white.withOpacity(0.06),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            data['counselorName'] ?? '',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ),
                        Text(
                          '${date.day}/${date.month}/${date.year}',
                          style: const TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      data['notes'] ?? '',
                      style: const TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                    if (followUp) ...[
                      const SizedBox(height: 8),
                      Row(
                        children: const [
                          Icon(Icons.flag, color: kAmber, size: 14),
                          SizedBox(width: 4),
                          Text('Follow-up required',
                              style: TextStyle(color: kAmber, fontSize: 12, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}