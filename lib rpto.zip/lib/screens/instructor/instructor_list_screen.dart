import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/instructor_model.dart';
import '../../config/constants.dart';
import 'instructor_add_screen.dart';
import 'instructor_detail_screen.dart';

// ---- Premium theme, scoped to this screen (matches detail screens) ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pAccent = Color(0xFF2DD4BF);
const Color _pGold = Color(0xFFC9A24B);
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pDanger = Color(0xFFE0685A);

class InstructorListScreen extends StatefulWidget {
  const InstructorListScreen({super.key});

  @override
  State<InstructorListScreen> createState() => _InstructorListScreenState();
}

class _InstructorListScreenState extends State<InstructorListScreen> {
  String _searchQuery = '';
  final _searchController = TextEditingController();
  String _selectedFilter = 'All';
  final List<String> _filters = ['All', 'Active', 'Inactive'];

  Stream<QuerySnapshot> _instructorStream() {
    return FirebaseFirestore.instance
        .collection('instructors')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _pBackground,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: _pBackground,
            pinned: true,
            expandedHeight: 130,
            elevation: 0,
            iconTheme: const IconThemeData(color: _pTextPrimary),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              title: Text(
                'Instructors',
                style: GoogleFonts.plusJakartaSans(
                  color: _pTextPrimary,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                ),
              ),
              background: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_pAccent.withValues(alpha: 0.35), _pBackground],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: _searchController,
                style: GoogleFonts.plusJakartaSans(color: _pTextPrimary),
                onChanged: (val) => setState(() => _searchQuery = val.toLowerCase()),
                decoration: InputDecoration(
                  hintText: 'Search instructor name...',
                  hintStyle: GoogleFonts.plusJakartaSans(color: _pTextSecondary),
                  prefixIcon: const Icon(Icons.search, color: _pTextSecondary),
                  filled: true,
                  fillColor: _pSurface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _filters.length,
                itemBuilder: (context, index) {
                  final filter = _filters[index];
                  final isSelected = _selectedFilter == filter;
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: ChoiceChip(
                      label: Text(filter),
                      selected: isSelected,
                      onSelected: (_) => setState(() => _selectedFilter = filter),
                      selectedColor: _pAccent,
                      backgroundColor: _pSurface,
                      labelStyle: GoogleFonts.plusJakartaSans(
                        color: isSelected ? _pBackground : _pTextSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(
                          color: isSelected ? _pAccent : Colors.white.withValues(alpha: 0.08),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 12)),
          StreamBuilder<QuerySnapshot>(
            stream: _instructorStream(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator(color: _pAccent)),
                );
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text('No instructors found',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
                  ),
                );
              }

              var instructors = snapshot.data!.docs
                  .map((d) => InstructorModel.fromDocument(d))
                  .where((i) => _selectedFilter == 'All' || i.status == _selectedFilter)
                  .where((i) => _searchQuery.isEmpty || i.name.toLowerCase().contains(_searchQuery))
                  .toList();

              if (instructors.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text('No matching instructors',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
                  ),
                );
              }

              return SliverList(
                delegate: SliverChildBuilderDelegate(
                      (context, index) => _buildInstructorCard(instructors[index]),
                  childCount: instructors.length,
                ),
              );
            },
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _pAccent,
        icon: Icon(Icons.add, color: _pBackground),
        label: Text(
          'Add Instructor',
          style: GoogleFonts.plusJakartaSans(color: _pBackground, fontWeight: FontWeight.w700),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const InstructorAddScreen()),
          );
        },
      ),
    );
  }

  Widget _buildInstructorCard(InstructorModel instructor) {
    final isActive = instructor.status == 'Active';
    final statusColor = isActive ? _pSuccess : _pDanger;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => InstructorDetailScreen(instructor: instructor),
          ),
        );
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _pSurface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: statusColor.withValues(alpha: 0.28)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_pGold.withValues(alpha: 0.7), _pAccent.withValues(alpha: 0.5)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: CircleAvatar(
                radius: 22,
                backgroundColor: _pBackground,
                backgroundImage: instructor.profileImageUrl != null
                    ? NetworkImage(instructor.profileImageUrl!)
                    : null,
                child: instructor.profileImageUrl == null
                    ? Text(
                  instructor.name.isNotEmpty ? instructor.name[0].toUpperCase() : '?',
                  style: GoogleFonts.plusJakartaSans(
                    color: _pAccent,
                    fontWeight: FontWeight.w700,
                    fontSize: 17,
                  ),
                )
                    : null,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          instructor.name,
                          style: GoogleFonts.plusJakartaSans(
                            color: _pTextPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: statusColor.withValues(alpha: 0.45)),
                        ),
                        child: Text(
                          instructor.status,
                          style: GoogleFonts.plusJakartaSans(
                            color: statusColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    instructor.specialization,
                    style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 12),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(Icons.badge_outlined, color: _pTextSecondary.withValues(alpha: 0.7), size: 14),
                      const SizedBox(width: 4),
                      Text(
                        instructor.licenseNumber,
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 11),
                      ),
                      const SizedBox(width: 12),
                      Icon(Icons.work_outline, color: _pTextSecondary.withValues(alpha: 0.7), size: 14),
                      const SizedBox(width: 4),
                      Text(
                        '${instructor.experienceYears} yrs',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 11),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: _pTextSecondary.withValues(alpha: 0.6)),
          ],
        ),
      ),
    );
  }
}