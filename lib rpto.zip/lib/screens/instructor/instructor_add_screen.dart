import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../models/company_model.dart';
import '../../config/constants.dart';
import '../../widgets/attach_document_button.dart';

// NOTE: This screen now uses PlatformFile (with .bytes) instead of
// dart:io File, so document upload works correctly on Flutter Web
// as well as Android/iOS/Desktop.

class InstructorAddScreen extends StatefulWidget {
  const InstructorAddScreen({super.key});

  @override
  State<InstructorAddScreen> createState() => _InstructorAddScreenState();
}

class _InstructorAddScreenState extends State<InstructorAddScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _licenseController = TextEditingController();
  final _experienceController = TextEditingController();

  String? _selectedSpecialization;
  String? _selectedCompanyId;
  String? _selectedCompanyName;
  String _status = 'Active';

  bool _isLoadingCompanies = true;
  bool _isSaving = false;
  List<CompanyModel> _companies = [];

  // --- Documents state (collected locally until instructor is saved) ---
  List<AttachedDocument> _documents = [];

  final List<String> _specializations = [
    'Fixed Wing',
    'Multirotor',
    'VTOL',
    'FPV',
    'Simulator Training',
  ];

  @override
  void initState() {
    super.initState();
    _loadCompanies();
  }

  Future<void> _loadCompanies() async {
    setState(() => _isLoadingCompanies = true);
    try {
      final snap = await FirebaseFirestore.instance.collection('companies').get();
      setState(() {
        _companies = snap.docs.map((d) => CompanyModel.fromDocument(d)).toList();
        _isLoadingCompanies = false;
      });
    } catch (e) {
      setState(() => _isLoadingCompanies = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load companies: $e'), backgroundColor: kCoral),
        );
      }
    }
  }

  Future<void> _saveInstructor() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedSpecialization == null || _selectedCompanyId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields'), backgroundColor: kCoral),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      await FirebaseFirestore.instance.collection('instructors').add({
        'name': _nameController.text.trim(),
        'email': _emailController.text.trim(),
        'phone': _phoneController.text.trim(),
        'licenseNumber': _licenseController.text.trim(),
        'specialization': _selectedSpecialization,
        'experienceYears': int.tryParse(_experienceController.text.trim()) ?? 0,
        'companyId': _selectedCompanyId,
        'companyName': _selectedCompanyName,
        'status': _status,
        'profileImageUrl': null,
        'documents': _documents.map((d) => d.toMap()).toList(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Instructor added successfully'), backgroundColor: kGreen),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save: $e'), backgroundColor: kCoral),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _licenseController.dispose();
    _experienceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      appBar: AppBar(
        backgroundColor: kNavy,
        title: const Text('Add Instructor', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _isLoadingCompanies
          ? const Center(child: CircularProgressIndicator(color: kTeal))
          : Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildLabel('Full Name'),
            TextFormField(
              controller: _nameController,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. Rajesh Kumar'),
              validator: (val) => val == null || val.trim().isEmpty ? 'Name required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('Email'),
            TextFormField(
              controller: _emailController,
              keyboardType: TextInputType.emailAddress,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. instructor@cda.com'),
              validator: (val) {
                if (val == null || val.trim().isEmpty) return 'Email required';
                if (!val.contains('@')) return 'Enter a valid email';
                return null;
              },
            ),
            const SizedBox(height: 16),

            _buildLabel('Phone Number'),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. 9876543210'),
              validator: (val) => val == null || val.trim().isEmpty ? 'Phone required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('License Number'),
            TextFormField(
              controller: _licenseController,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. RPTO/LIC/2026/001'),
              validator: (val) => val == null || val.trim().isEmpty ? 'License number required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('Documents'),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kSurface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.06)),
              ),
              child: AttachDocumentButton(
                initialDocuments: _documents,
                onDocumentsChanged: (docs) => setState(() => _documents = docs),
              ),
            ),
            const SizedBox(height: 16),

            _buildLabel('Specialization'),
            DropdownButtonFormField<String>(
              value: _selectedSpecialization,
              dropdownColor: kSurface,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('Select specialization'),
              items: _specializations
                  .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                  .toList(),
              onChanged: (val) => setState(() => _selectedSpecialization = val),
            ),
            const SizedBox(height: 16),

            _buildLabel('Company / Branch'),
            DropdownButtonFormField<String>(
              value: _selectedCompanyId,
              dropdownColor: kSurface,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('Select company'),
              items: _companies
                  .map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))
                  .toList(),
              onChanged: (val) {
                setState(() {
                  _selectedCompanyId = val;
                  _selectedCompanyName = _companies.firstWhere((c) => c.id == val).name;
                });
              },
            ),
            const SizedBox(height: 16),

            _buildLabel('Experience (Years)'),
            TextFormField(
              controller: _experienceController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. 5'),
              validator: (val) => val == null || val.trim().isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('Status'),
            Row(
              children: ['Active', 'Inactive'].map((s) {
                final isSelected = _status == s;
                return Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: ChoiceChip(
                    label: Text(s),
                    selected: isSelected,
                    onSelected: (_) => setState(() => _status = s),
                    selectedColor: kTeal,
                    backgroundColor: kSurface,
                    labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.white54),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _saveInstructor,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kTeal,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _isSaving
                    ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                )
                    : const Text('Add Instructor',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(text, style: kLabelStyle),
    );
  }
}