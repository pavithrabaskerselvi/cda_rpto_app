import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/drone_model.dart';

const kNavy = Color(0xFF050A14);
const kTeal = Color(0xFF14B8A6);
const kSurface = Color(0xFF0F1B2E);

class AddDroneScreen extends StatefulWidget {
  final DroneModel? existingDrone; // null => add mode, else edit mode
  const AddDroneScreen({super.key, this.existingDrone});

  @override
  State<AddDroneScreen> createState() => _AddDroneScreenState();
}

class _AddDroneScreenState extends State<AddDroneScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameCtrl;
  late TextEditingController _modelCtrl;
  late TextEditingController _serialCtrl;

  String _type = 'Multirotor';
  String _status = 'Available';
  String? _companyId;
  String? _companyName;
  DateTime? _lastMaintenanceDate;
  bool _saving = false;

  final List<String> _types = ['Fixed Wing', 'Multirotor', 'VTOL'];
  final List<String> _statuses = ['Available', 'In Use', 'Under Maintenance'];

  bool get _isEdit => widget.existingDrone != null;

  @override
  void initState() {
    super.initState();
    final d = widget.existingDrone;
    _nameCtrl = TextEditingController(text: d?.droneName ?? '');
    _modelCtrl = TextEditingController(text: d?.model ?? '');
    _serialCtrl = TextEditingController(text: d?.serialNumber ?? '');
    _type = d?.type.isNotEmpty == true ? d!.type : 'Multirotor';
    _status = d?.status ?? 'Available';
    _companyId = d?.companyId;
    _companyName = d?.companyName;
    _lastMaintenanceDate = d?.lastMaintenanceDate;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _modelCtrl.dispose();
    _serialCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _lastMaintenanceDate ?? DateTime.now(),
      firstDate: DateTime(2015),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(primary: kTeal, surface: kSurface),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _lastMaintenanceDate = picked);
  }

  Future<void> _saveDrone() async {
    if (!_formKey.currentState!.validate()) return;
    if (_companyId == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Select a company')));
      return;
    }
    setState(() => _saving = true);

    try {
      final docRef = _isEdit
          ? FirebaseFirestore.instance.collection('drones').doc(widget.existingDrone!.id)
          : FirebaseFirestore.instance.collection('drones').doc();

      final drone = DroneModel(
        id: docRef.id,
        droneName: _nameCtrl.text.trim(),
        model: _modelCtrl.text.trim(),
        serialNumber: _serialCtrl.text.trim(),
        type: _type,
        companyId: _companyId!,
        companyName: _companyName ?? '',
        status: _status,
        lastMaintenanceDate: _lastMaintenanceDate,
        createdAt: widget.existingDrone?.createdAt ?? DateTime.now(),
        updatedAt: _isEdit ? DateTime.now() : null,
      );

      await docRef.set(drone.toMap());

      if (mounted) {
        Navigator.pop(context);
        if (_isEdit) Navigator.pop(context); // also close details screen after edit
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Error saving drone: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _decoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.grey),
      filled: true,
      fillColor: kSurface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: kNavy,
            pinned: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text(
              _isEdit ? 'Edit Drone' : 'Add Drone',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextFormField(
                      controller: _nameCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration('Drone Name *'),
                      validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _modelCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration('Model'),
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _serialCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration('Serial Number'),
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      initialValue: _type,
                      dropdownColor: kSurface,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration('Type'),
                      items:
                      _types.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                      onChanged: (v) => setState(() => _type = v!),
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      initialValue: _status,
                      dropdownColor: kSurface,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration('Status'),
                      items: _statuses
                          .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                          .toList(),
                      onChanged: (v) => setState(() => _status = v!),
                    ),
                    const SizedBox(height: 14),
                    StreamBuilder<QuerySnapshot>(
                      stream:
                      FirebaseFirestore.instance.collection('companies').snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const LinearProgressIndicator(color: kTeal);
                        }
                        final companies = snapshot.data!.docs;
                        // Ensure current selection still exists in dropdown items
                        final validIds = companies.map((c) => c.id).toSet();
                        final currentValue =
                        (_companyId != null && validIds.contains(_companyId))
                            ? _companyId
                            : null;
                        return DropdownButtonFormField<String>(
                          initialValue: currentValue,
                          dropdownColor: kSurface,
                          style: const TextStyle(color: Colors.white),
                          decoration: _decoration('Company *'),
                          items: companies.map((c) {
                            final data = c.data() as Map<String, dynamic>;
                            final name = data['companyName'] ?? data['name'] ?? c.id;
                            return DropdownMenuItem(value: c.id, child: Text(name));
                          }).toList(),
                          onChanged: (v) {
                            final match = companies.firstWhere((c) => c.id == v);
                            final data = match.data() as Map<String, dynamic>;
                            setState(() {
                              _companyId = v;
                              _companyName = data['companyName'] ?? data['name'] ?? '';
                            });
                          },
                          validator: (v) => v == null ? 'Select a company' : null,
                        );
                      },
                    ),
                    const SizedBox(height: 14),
                    InkWell(
                      onTap: _pickDate,
                      child: InputDecorator(
                        decoration: _decoration('Last Maintenance Date'),
                        child: Text(
                          _lastMaintenanceDate != null
                              ? '${_lastMaintenanceDate!.day}/${_lastMaintenanceDate!.month}/${_lastMaintenanceDate!.year}'
                              : 'Select date',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: _saving ? null : _saveDrone,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kTeal,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: _saving
                          ? const SizedBox(
                        height: 20,
                        width: 20,
                        child:
                        CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      )
                          : Text(
                        _isEdit ? 'Update Drone' : 'Save Drone',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}