import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/drone_model.dart';
import 'drone_detail_screen.dart';
import 'drone_add_screen.dart';

// ---- Premium theme, matching CompanyDetailScreen ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pSurfaceElevated = Color(0xFF161B29);
const Color _pAccent = Color(0xFF2DD4BF); // richer teal
const Color _pGold = Color(0xFFC9A24B); // premium gold accent
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pTextMuted = Color(0xFF6B7280);
const Color _pDanger = Color(0xFFE0685A);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pAmber = Color(0xFFFFB020);

class DroneListScreen extends StatefulWidget {
  const DroneListScreen({super.key});

  @override
  State<DroneListScreen> createState() => _DroneListScreenState();
}

class _DroneListScreenState extends State<DroneListScreen> {
  String _searchQuery = '';
  String _selectedType = 'All';

  final List<String> _types = ['All', 'Fixed Wing', 'Multirotor', 'VTOL'];

  Color _statusColor(String status) {
    switch (status) {
      case 'Available':
        return _pSuccess;
      case 'In Use':
        return _pAccent;
      case 'Under Maintenance':
        return _pAmber;
      default:
        return _pDanger;
    }
  }

  // ---- gradient hero header, matching Company Details premium style ----
  Widget _header(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 50, 20, 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _pGold.withValues(alpha: 0.18),
            _pAccent.withValues(alpha: 0.12),
            _pBackground,
          ],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          IconButton(
            padding: EdgeInsets.zero,
            icon: const Icon(Icons.arrow_back, color: _pTextPrimary),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(height: 8),
          Text(
            'DroneList',
            style: GoogleFonts.plusJakartaSans(
              color: _pTextPrimary,
              fontSize: 28,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _searchAndFilters() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Column(
        children: [
          TextField(
            style: GoogleFonts.plusJakartaSans(color: _pTextPrimary),
            onChanged: (v) => setState(() => _searchQuery = v.toLowerCase()),
            decoration: InputDecoration(
              hintText: 'Search drone name / serial no...',
              hintStyle: GoogleFonts.plusJakartaSans(color: _pTextMuted),
              prefixIcon: const Icon(Icons.search, color: _pAccent),
              filled: true,
              fillColor: _pSurface,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 36,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _types.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final type = _types[index];
                final selected = type == _selectedType;
                return ChoiceChip(
                  label: Text(type),
                  selected: selected,
                  onSelected: (_) => setState(() => _selectedType = type),
                  selectedColor: _pAccent,
                  backgroundColor: _pSurface,
                  labelStyle: GoogleFonts.plusJakartaSans(
                    color: selected ? _pBackground : _pTextSecondary,
                    fontWeight: FontWeight.w600,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                    side: BorderSide.none,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _droneCard(BuildContext context, DroneModel drone) {
    final initial = drone.droneName.isNotEmpty ? drone.droneName[0].toUpperCase() : '?';
    final statusColor = _statusColor(drone.status);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: _pSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: statusColor.withValues(alpha: 0.35)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => DroneDetailsScreen(drone: drone)),
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      _pGold.withValues(alpha: 0.7),
                      _pAccent.withValues(alpha: 0.6),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: _pSurfaceElevated,
                  child: Text(
                    initial,
                    style: GoogleFonts.plusJakartaSans(
                        color: _pAccent, fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      drone.droneName,
                      style: GoogleFonts.plusJakartaSans(
                          color: _pTextPrimary, fontWeight: FontWeight.w700, fontSize: 15.5),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${drone.model} • ${drone.serialNumber}',
                      style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 12.5),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      drone.companyName,
                      style: GoogleFonts.plusJakartaSans(color: _pTextMuted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      drone.status,
                      style: GoogleFonts.plusJakartaSans(
                          color: statusColor, fontWeight: FontWeight.w600, fontSize: 11),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Icon(Icons.chevron_right, color: _pTextMuted, size: 20),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _pBackground,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _pAccent,
        foregroundColor: _pBackground,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddDroneScreen()),
          );
        },
        icon: const Icon(Icons.add),
        label: Text('Add Drone', style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600)),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _header(context),
          _searchAndFilters(),
          const SizedBox(height: 8),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('drones')
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Error: ${snapshot.error}',
                        style: GoogleFonts.plusJakartaSans(color: _pTextPrimary)),
                  );
                }
                if (!snapshot.hasData) {
                  return const Center(
                      child: CircularProgressIndicator(color: _pAccent));
                }

                var drones = snapshot.data!.docs
                    .map((doc) => DroneModel.fromDocument(doc))
                    .where((d) {
                  final matchesType = _selectedType == 'All' || d.type == _selectedType;
                  final matchesSearch = _searchQuery.isEmpty ||
                      d.droneName.toLowerCase().contains(_searchQuery) ||
                      d.serialNumber.toLowerCase().contains(_searchQuery);
                  return matchesType && matchesSearch;
                }).toList();

                if (drones.isEmpty) {
                  return Center(
                    child: Text('No drones found',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 16)),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                  itemCount: drones.length,
                  itemBuilder: (context, index) => _droneCard(context, drones[index]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}