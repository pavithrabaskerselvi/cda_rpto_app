import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/drone_model.dart';
import '../document/documents_screen.dart';
import 'drone_add_screen.dart';

// ---- Premium theme, matching CompanyDetailScreen & DroneListScreen ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pAccent = Color(0xFF2DD4BF); // richer teal
const Color _pGold = Color(0xFFC9A24B); // premium gold accent
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pDanger = Color(0xFFE0685A);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pAmber = Color(0xFFFFB020);

class DroneDetailsScreen extends StatelessWidget {
  final DroneModel drone;
  const DroneDetailsScreen({super.key, required this.drone});

  Color _statusColor(String status) {
    switch (status) {
      case 'Available':
        return _pSuccess;
      case 'In Use':
        return _pAccent;
      case 'Under Maintenance':
        return _pAmber;
      default:
        return _pDanger;
    }
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _pSurface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Delete Drone',
            style: GoogleFonts.plusJakartaSans(
                color: _pTextPrimary, fontWeight: FontWeight.w700)),
        content: Text('Delete ${drone.droneName}? This cannot be undone.',
            style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
          ),
          TextButton(
            onPressed: () async {
              await FirebaseFirestore.instance.collection('drones').doc(drone.id).delete();
              if (context.mounted) {
                Navigator.pop(context); // close dialog
                Navigator.pop(context); // back to list
              }
            },
            child: Text('Delete',
                style: GoogleFonts.plusJakartaSans(
                    color: _pDanger, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  void _openDocuments(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DocumentsScreen(
          title: '${drone.droneName} Documents',
          firestorePath: 'drones/${drone.id}',
          requirements: const [
            DocumentRequirement(
                key: 'registration_certificate', label: 'Registration Certificate'),
            DocumentRequirement(key: 'insurance', label: 'Insurance'),
            DocumentRequirement(key: 'manual', label: 'Manual', required: false),
          ],
        ),
      ),
    );
  }

  // ---- gradient hero header, matching Company Details / DroneList premium style ----
  Widget _header(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 50, 20, 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _pGold.withValues(alpha: 0.18),
            _pAccent.withValues(alpha: 0.12),
            _pBackground,
          ],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconButton(
                padding: EdgeInsets.zero,
                icon: const Icon(Icons.arrow_back, color: _pTextPrimary),
                onPressed: () => Navigator.pop(context),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.edit, color: _pTextPrimary),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => AddDroneScreen(existingDrone: drone)),
                  );
                },
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: _pTextPrimary),
                onPressed: () => _confirmDelete(context),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Drone Details',
            style: GoogleFonts.plusJakartaSans(
              color: _pTextPrimary,
              fontSize: 28,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.2,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Text(
                  drone.droneName,
                  style: GoogleFonts.plusJakartaSans(
                      color: _pTextSecondary, fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _statusColor(drone.status).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _statusColor(drone.status).withValues(alpha: 0.4)),
                ),
                child: Text(
                  drone.status,
                  style: GoogleFonts.plusJakartaSans(
                      color: _statusColor(drone.status),
                      fontWeight: FontWeight.w600,
                      fontSize: 13),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ---- one row-card, matching the avatar + title/subtitle + chevron style ----
  Widget _rowCard({
    required IconData icon,
    required String label,
    required String value,
    VoidCallback? onTap,
    bool danger = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _pSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: danger ? _pDanger.withValues(alpha: 0.4) : Colors.white.withValues(alpha: 0.06)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      _pGold.withValues(alpha: 0.6),
                      _pAccent.withValues(alpha: 0.5),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Container(
                  margin: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: _pBackground,
                  ),
                  child: Icon(icon, color: _pAccent, size: 18),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: GoogleFonts.plusJakartaSans(
                            color: _pTextSecondary, fontSize: 12.5)),
                    const SizedBox(height: 3),
                    Text(
                      value.isEmpty ? '-' : value,
                      style: GoogleFonts.plusJakartaSans(
                          color: _pTextPrimary, fontSize: 15, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              if (onTap != null)
                const Icon(Icons.chevron_right, color: _pTextSecondary),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _pBackground,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _header(context),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _rowCard(icon: Icons.precision_manufacturing_outlined, label: 'Model', value: drone.model),
                _rowCard(icon: Icons.qr_code_2, label: 'Serial Number', value: drone.serialNumber),
                _rowCard(icon: Icons.category_outlined, label: 'Type', value: drone.type),
                _rowCard(icon: Icons.apartment_outlined, label: 'Company', value: drone.companyName),
                _rowCard(
                  icon: Icons.build_outlined,
                  label: 'Last Maintenance',
                  value: drone.lastMaintenanceDate != null
                      ? DateFormat('dd MMM yyyy').format(drone.lastMaintenanceDate!)
                      : '',
                ),
                _rowCard(
                  icon: Icons.calendar_today_outlined,
                  label: 'Added On',
                  value: DateFormat('dd MMM yyyy').format(drone.createdAt),
                ),
                if (drone.updatedAt != null)
                  _rowCard(
                    icon: Icons.update,
                    label: 'Last Updated',
                    value: DateFormat('dd MMM yyyy, hh:mm a').format(drone.updatedAt!),
                  ),
                const SizedBox(height: 4),
                _rowCard(
                  icon: Icons.description_outlined,
                  label: 'Attachments',
                  value: 'Documents',
                  onTap: () => _openDocuments(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}