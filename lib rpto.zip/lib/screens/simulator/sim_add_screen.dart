import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../config/constants.dart';

class SimAddScreen extends StatefulWidget {
  const SimAddScreen({super.key});

  @override
  State<SimAddScreen> createState() => _SimAddScreenState();
}

class _SimAddScreenState extends State<SimAddScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _modelController = TextEditingController();
  final _serialController = TextEditingController();

  String _status = 'Available';
  bool _isSaving = false;

  String? _selectedCompanyId;
  String? _selectedCompanyName;

  Future<void> _saveSimulator() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCompanyId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a company/branch'), backgroundColor: kCoral),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      await FirebaseFirestore.instance.collection('simulators').add({
        'simulatorName': _nameController.text.trim(),
        'model': _modelController.text.trim(),
        'serialNumber': _serialController.text.trim(),
        'companyId': _selectedCompanyId,
        'companyName': _selectedCompanyName,
        'status': _status,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Simulator added successfully'), backgroundColor: kGreen),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save: $e'), backgroundColor: kCoral),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _modelController.dispose();
    _serialController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kNavy,
      appBar: AppBar(
        backgroundColor: kNavy,
        title: const Text('Add Simulator', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildLabel('Simulator Name'),
            TextFormField(
              controller: _nameController,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. VR Drone Sim Unit 1'),
              validator: (val) => val == null || val.trim().isEmpty ? 'Name required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('Model'),
            TextFormField(
              controller: _modelController,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. DJI FlightSim Pro'),
              validator: (val) => val == null || val.trim().isEmpty ? 'Model required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('Serial Number'),
            TextFormField(
              controller: _serialController,
              style: const TextStyle(color: Colors.white),
              decoration: kFieldDecoration('e.g. SN-2026-00123'),
              validator: (val) => val == null || val.trim().isEmpty ? 'Serial number required' : null,
            ),
            const SizedBox(height: 16),

            _buildLabel('Company / Branch'),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('companies').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator(color: kTeal));
                }
                final companies = snapshot.data!.docs;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: kSurface,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      isExpanded: true,
                      dropdownColor: kSurface,
                      value: _selectedCompanyId,
                      hint: const Text('Select company/branch', style: TextStyle(color: Colors.white38)),
                      style: const TextStyle(color: Colors.white),
                      items: companies.map((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        return DropdownMenuItem<String>(
                          value: doc.id,
                          child: Text(data['name'] ?? ''),
                          onTap: () => _selectedCompanyName = data['name'] ?? '',
                        );
                      }).toList(),
                      onChanged: (val) => setState(() => _selectedCompanyId = val),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            _buildLabel('Status'),
            Row(
              children: ['Available', 'In Use', 'Under Maintenance'].map((s) {
                final isSelected = _status == s;
                return Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: ChoiceChip(
                    label: Text(s, style: const TextStyle(fontSize: 12)),
                    selected: isSelected,
                    onSelected: (_) => setState(() => _status = s),
                    selectedColor: kPurple,
                    backgroundColor: kSurface,
                    labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.white54),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _saveSimulator,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPurple,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _isSaving
                    ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                )
                    : const Text('Add Simulator', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(text, style: kLabelStyle),
    );
  }
}