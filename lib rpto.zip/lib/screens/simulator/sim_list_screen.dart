import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/simulator_model.dart';
import 'sim_add_screen.dart';
import 'sim_detail_screen.dart';

// ---- Premium theme, matching DroneList / Drone Details / Company Details ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pAccent = Color(0xFF2DD4BF); // richer teal
const Color _pGold = Color(0xFFC9A24B); // premium gold accent
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pTextMuted = Color(0xFF6B7280);
const Color _pDanger = Color(0xFFE0685A);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pAmber = Color(0xFFFFB020);

Color _statusColor(String status) {
  switch (status) {
    case 'Available':
      return _pSuccess;
    case 'In Use':
      return _pAccent;
    case 'Under Maintenance':
      return _pAmber;
    default:
      return _pDanger;
  }
}

class SimListScreen extends StatefulWidget {
  const SimListScreen({super.key});

  @override
  State<SimListScreen> createState() => _SimListScreenState();
}

class _SimListScreenState extends State<SimListScreen> {
  String _searchQuery = '';
  final _searchController = TextEditingController();
  String _selectedFilter = 'All';
  final List<String> _filters = ['All', 'Available', 'In Use', 'Under Maintenance'];

  Stream<QuerySnapshot> _simStream() {
    return FirebaseFirestore.instance
        .collection('simulators')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _pBackground,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: _pBackground,
            pinned: true,
            expandedHeight: 130,
            iconTheme: const IconThemeData(color: _pTextPrimary),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              title: Text(
                'Simulators',
                style: GoogleFonts.plusJakartaSans(
                  color: _pTextPrimary,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              background: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      _pGold.withValues(alpha: 0.18),
                      _pAccent.withValues(alpha: 0.12),
                      _pBackground,
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: _searchController,
                style: GoogleFonts.plusJakartaSans(color: _pTextPrimary),
                onChanged: (val) => setState(() => _searchQuery = val.toLowerCase()),
                decoration: InputDecoration(
                  hintText: 'Search simulator name or model...',
                  hintStyle: GoogleFonts.plusJakartaSans(color: _pTextMuted),
                  prefixIcon: const Icon(Icons.search, color: _pAccent),
                  filled: true,
                  fillColor: _pSurface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _filters.length,
                itemBuilder: (context, index) {
                  final filter = _filters[index];
                  final isSelected = _selectedFilter == filter;
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: ChoiceChip(
                      label: Text(filter),
                      selected: isSelected,
                      onSelected: (_) => setState(() => _selectedFilter = filter),
                      selectedColor: _pAccent,
                      backgroundColor: _pSurface,
                      labelStyle: GoogleFonts.plusJakartaSans(
                        color: isSelected ? _pBackground : _pTextSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide.none,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 12)),
          StreamBuilder<QuerySnapshot>(
            stream: _simStream(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator(color: _pAccent)),
                );
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                      child: Text('No simulators found',
                          style: GoogleFonts.plusJakartaSans(color: _pTextSecondary))),
                );
              }

              var sims = snapshot.data!.docs
                  .map((d) => SimulatorModel.fromDocument(d))
                  .where((s) => _selectedFilter == 'All' || s.status == _selectedFilter)
                  .where((s) => _searchQuery.isEmpty ||
                  s.simulatorName.toLowerCase().contains(_searchQuery) ||
                  s.model.toLowerCase().contains(_searchQuery))
                  .toList();

              if (sims.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                      child: Text('No matching simulators',
                          style: GoogleFonts.plusJakartaSans(color: _pTextSecondary))),
                );
              }

              return SliverList(
                delegate: SliverChildBuilderDelegate(
                      (context, index) => _buildSimCard(context, sims[index]),
                  childCount: sims.length,
                ),
              );
            },
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _pAccent,
        foregroundColor: _pBackground,
        icon: const Icon(Icons.add),
        label: Text('Add Simulator', style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600)),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SimAddScreen()),
          );
        },
      ),
    );
  }

  Widget _buildSimCard(BuildContext context, SimulatorModel sim) {
    final statusColor = _statusColor(sim.status);
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => SimDetailScreen(simulator: sim)),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _pSurface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: statusColor.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_pGold.withValues(alpha: 0.7), _pAccent.withValues(alpha: 0.6)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: CircleAvatar(
                radius: 22,
                backgroundColor: _pBackground,
                child: const Icon(Icons.sports_esports, color: _pAccent, size: 20),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          sim.simulatorName,
                          style: GoogleFonts.plusJakartaSans(
                              color: _pTextPrimary, fontSize: 15, fontWeight: FontWeight.w700),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: statusColor.withValues(alpha: 0.4)),
                        ),
                        child: Text(
                          sim.status,
                          style: GoogleFonts.plusJakartaSans(
                              color: statusColor, fontSize: 10, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(sim.model,
                      style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 12)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.apartment, color: _pTextMuted, size: 14),
                      const SizedBox(width: 4),
                      Text(sim.companyName,
                          style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 11)),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: _pTextMuted),
          ],
        ),
      ),
    );
  }
}