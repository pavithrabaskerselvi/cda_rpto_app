import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/simulator_model.dart';
import '../document/documents_screen.dart';

// ---- Premium theme, matching DroneDetails / DroneList / Company Details ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pAccent = Color(0xFF2DD4BF); // richer teal
const Color _pGold = Color(0xFFC9A24B); // premium gold accent
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pDanger = Color(0xFFE0685A);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pAmber = Color(0xFFFFB020);

Color _statusColor(String status) {
  switch (status) {
    case 'Available':
      return _pSuccess;
    case 'In Use':
      return _pAccent;
    case 'Under Maintenance':
      return _pAmber;
    default:
      return _pDanger;
  }
}

class SimDetailScreen extends StatefulWidget {
  final SimulatorModel simulator;

  const SimDetailScreen({super.key, required this.simulator});

  @override
  State<SimDetailScreen> createState() => _SimDetailScreenState();
}

class _SimDetailScreenState extends State<SimDetailScreen> {
  bool _isDeleting = false;
  bool _savingDocs = false;

  Future<void> _confirmDelete() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _pSurface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Delete Simulator',
            style: GoogleFonts.plusJakartaSans(
                color: _pTextPrimary, fontWeight: FontWeight.w700)),
        content: Text(
          'Are you sure you want to delete ${widget.simulator.simulatorName}? This cannot be undone.',
          style: GoogleFonts.plusJakartaSans(color: _pTextSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel', style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Delete',
                style: GoogleFonts.plusJakartaSans(
                    color: _pDanger, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      setState(() => _isDeleting = true);
      try {
        await FirebaseFirestore.instance
            .collection('simulators')
            .doc(widget.simulator.id)
            .delete();
        if (mounted) {
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text('Simulator deleted', style: GoogleFonts.plusJakartaSans()),
                backgroundColor: _pSuccess),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text('Failed to delete: $e', style: GoogleFonts.plusJakartaSans()),
                backgroundColor: _pDanger),
          );
        }
      } finally {
        setState(() => _isDeleting = false);
      }
    }
  }

  Future<void> _cycleStatus() async {
    const statuses = ['Available', 'In Use', 'Under Maintenance'];
    final currentIndex = statuses.indexOf(widget.simulator.status);
    final newStatus = statuses[(currentIndex + 1) % statuses.length];
    try {
      await FirebaseFirestore.instance
          .collection('simulators')
          .doc(widget.simulator.id)
          .update({'status': newStatus, 'updatedAt': FieldValue.serverTimestamp()});

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Status changed to $newStatus', style: GoogleFonts.plusJakartaSans()),
              backgroundColor: _pSuccess),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed: $e', style: GoogleFonts.plusJakartaSans()), backgroundColor: _pDanger),
        );
      }
    }
  }

  void _openDocuments() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DocumentsScreen(
          title: '${widget.simulator.simulatorName} Documents',
          firestorePath: 'simulators/${widget.simulator.id}',
          requirements: const [
            DocumentRequirement(key: 'manual', label: 'Manual', required: false),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sim = widget.simulator;
    final statusColor = _statusColor(sim.status);

    return Scaffold(
      backgroundColor: _pBackground,
      appBar: AppBar(
        backgroundColor: _pBackground,
        elevation: 0,
        title: Text(sim.simulatorName,
            style: GoogleFonts.plusJakartaSans(
                color: _pTextPrimary, fontWeight: FontWeight.w700, fontSize: 18)),
        iconTheme: const IconThemeData(color: _pTextPrimary),
        actions: [
          IconButton(
            icon: _isDeleting
                ? const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(color: _pDanger, strokeWidth: 2),
            )
                : const Icon(Icons.delete_outline, color: _pDanger),
            onPressed: _isDeleting ? null : _confirmDelete,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [_pGold.withValues(alpha: 0.8), _pAccent.withValues(alpha: 0.6)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: CircleAvatar(
                    radius: 42,
                    backgroundColor: _pSurface,
                    child: const Icon(Icons.sports_esports, color: _pAccent, size: 36),
                  ),
                ),
                const SizedBox(height: 14),
                Text(sim.simulatorName,
                    style: GoogleFonts.plusJakartaSans(
                        color: _pTextPrimary, fontSize: 21, fontWeight: FontWeight.w800),
                    textAlign: TextAlign.center),
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: _cycleStatus,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor.withValues(alpha: 0.45)),
                    ),
                    child: Text(
                      '${sim.status} · tap to change',
                      style: GoogleFonts.plusJakartaSans(
                          color: statusColor, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          _buildSectionLabel('Details'),
          const SizedBox(height: 10),
          _buildInfoCard([
            _buildInfoRow(Icons.devices_other_outlined, 'Model', sim.model),
            _buildInfoRow(Icons.numbers_outlined, 'Serial Number', sim.serialNumber),
          ]),
          const SizedBox(height: 20),
          _buildSectionLabel('Company'),
          const SizedBox(height: 10),
          _buildInfoCard([
            _buildInfoRow(Icons.apartment_outlined, 'Company / Branch', sim.companyName),
          ]),
          const SizedBox(height: 20),
          _buildSectionLabel('Timeline'),
          const SizedBox(height: 10),
          _buildInfoCard([
            _buildInfoRow(
              Icons.calendar_today_outlined,
              'Added On',
              '${sim.createdAt.day}/${sim.createdAt.month}/${sim.createdAt.year}',
            ),
          ]),
          const SizedBox(height: 20),
          _buildSectionLabel('Documents'),
          const SizedBox(height: 10),
          _buildDocumentsCard(),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        text.toUpperCase(),
        style: GoogleFonts.plusJakartaSans(
          color: _pGold,
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.4,
        ),
      ),
    );
  }

  Widget _buildDocumentsCard() {
    return Container(
      decoration: BoxDecoration(
        color: _pSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: _openDocuments,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _pBackground,
                  border: Border.all(color: _pAccent.withValues(alpha: 0.5)),
                ),
                child: const Icon(Icons.description_outlined, color: _pAccent, size: 18),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Attachments',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 12.5)),
                    const SizedBox(height: 3),
                    Text('Documents',
                        style: GoogleFonts.plusJakartaSans(
                            color: _pTextPrimary, fontSize: 15, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: _pTextSecondary),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(List<Widget> children) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: _pSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _pAccent.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: _pAccent, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 12)),
                const SizedBox(height: 3),
                Text(
                  value.isEmpty ? '-' : value,
                  style: GoogleFonts.plusJakartaSans(
                      color: _pTextPrimary, fontSize: 14.5, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}