import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/student_model.dart';
import 'student_detail_screen.dart';
import 'student_add_screen.dart';

// ---- Premium theme, matching DroneList / DroneDetails / Simulators ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pAccent = Color(0xFF2DD4BF); // richer teal
const Color _pGold = Color(0xFFC9A24B); // premium gold accent
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pTextMuted = Color(0xFF6B7280);
const Color _pDanger = Color(0xFFE0685A);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pAmber = Color(0xFFFFB020);

class StudentListScreen extends StatefulWidget {
  const StudentListScreen({super.key});

  @override
  State<StudentListScreen> createState() => _StudentListScreenState();
}

class _StudentListScreenState extends State<StudentListScreen> {
  String _searchQuery = '';
  String _selectedStatus = 'All';
  String _selectedState = 'All'; // NEW
  String _selectedPlace = 'All'; // NEW

  final List<String> _statuses = ['All', 'Active', 'Completed', 'Dropped'];

  // NEW: holds the distinct list of states found in the current data
  final ValueNotifier<List<String>> _statesNotifier = ValueNotifier([]);
  // NEW: holds the distinct list of places found in the current data
  final ValueNotifier<List<String>> _placesNotifier = ValueNotifier([]);

  @override
  void dispose() {
    _statesNotifier.dispose(); // NEW
    _placesNotifier.dispose(); // NEW
    super.dispose();
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Active':
        return _pSuccess;
      case 'Completed':
        return _pAccent;
      case 'Dropped':
        return _pDanger;
      default:
        return _pAmber;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _pBackground,
      floatingActionButton: FloatingActionButton(
        backgroundColor: _pAccent,
        foregroundColor: _pBackground,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const StudentAddScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: _pBackground,
            pinned: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: _pTextPrimary),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text(
              'StudentList',
              style: GoogleFonts.plusJakartaSans(
                  color: _pTextPrimary, fontWeight: FontWeight.w800, fontSize: 22),
            ),
            flexibleSpace: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _pGold.withValues(alpha: 0.18),
                    _pAccent.withValues(alpha: 0.12),
                    _pBackground,
                  ],
                ),
              ),
            ),
            // NEW: increased height to fit two extra chip rows (110 -> 202)
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(202),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Column(
                  children: [
                    TextField(
                      style: GoogleFonts.plusJakartaSans(color: _pTextPrimary),
                      onChanged: (v) => setState(() => _searchQuery = v.toLowerCase()),
                      decoration: InputDecoration(
                        hintText: 'Search name / email / phone / state / place...',
                        hintStyle: GoogleFonts.plusJakartaSans(color: _pTextMuted),
                        prefixIcon: const Icon(Icons.search, color: _pAccent),
                        filled: true,
                        fillColor: _pSurface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 0),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // ---- Status chip row (unchanged) ----
                    SizedBox(
                      height: 36,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: _statuses.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (context, index) {
                          final s = _statuses[index];
                          final selected = s == _selectedStatus;
                          return ChoiceChip(
                            label: Text(s),
                            selected: selected,
                            onSelected: (_) => setState(() {
                              _selectedStatus = s;
                              if (s == 'All') {
                                _selectedState = 'All'; // NEW: reset together
                                _selectedPlace = 'All'; // NEW: reset together
                              }
                            }),
                            selectedColor: _pAccent,
                            backgroundColor: _pSurface,
                            labelStyle: GoogleFonts.plusJakartaSans(
                              color: selected ? _pBackground : _pTextSecondary,
                              fontWeight: FontWeight.w600,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide.none,
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 10), // NEW
                    // ---- NEW: State chip row (dynamic, built from live data) ----
                    ValueListenableBuilder<List<String>>(
                      valueListenable: _statesNotifier,
                      builder: (context, states, _) {
                        return SizedBox(
                          height: 36,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: states.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 8),
                            itemBuilder: (context, index) {
                              final s = states[index];
                              final selected = s == _selectedState;
                              return ChoiceChip(
                                label: Text(s),
                                selected: selected,
                                onSelected: (_) => setState(() => _selectedState = s),
                                selectedColor: _pGold,
                                backgroundColor: _pSurface,
                                labelStyle: GoogleFonts.plusJakartaSans(
                                  color: selected ? _pBackground : _pTextSecondary,
                                  fontWeight: FontWeight.w600,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  side: BorderSide.none,
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 10), // NEW
                    // ---- NEW: Place chip row (dynamic, built from live data) ----
                    ValueListenableBuilder<List<String>>(
                      valueListenable: _placesNotifier,
                      builder: (context, places, _) {
                        return SizedBox(
                          height: 36,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            itemCount: places.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 8),
                            itemBuilder: (context, index) {
                              final p = places[index];
                              final selected = p == _selectedPlace;
                              return ChoiceChip(
                                label: Text(p),
                                selected: selected,
                                onSelected: (_) => setState(() => _selectedPlace = p),
                                selectedColor: _pDanger,
                                backgroundColor: _pSurface,
                                labelStyle: GoogleFonts.plusJakartaSans(
                                  color: selected ? _pBackground : _pTextSecondary,
                                  fontWeight: FontWeight.w600,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  side: BorderSide.none,
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('students')
                .orderBy('createdAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text('Error: ${snapshot.error}',
                        style: GoogleFonts.plusJakartaSans(color: _pTextPrimary)),
                  ),
                );
              }
              if (!snapshot.hasData) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator(color: _pAccent)),
                );
              }

              final allStudents = snapshot.data!.docs
                  .map((doc) => StudentModel.fromDocument(doc))
                  .toList();

              // NEW: build distinct state list for the chip row, "All" always first
              final distinctStates = allStudents
                  .map((s) => s.state.trim())
                  .where((s) => s.isNotEmpty)
                  .toSet()
                  .toList()
                ..sort();
              final stateOptions = distinctStates; // UPDATED: no separate 'All' chip here

              // NEW: build distinct place list for the chip row, "All" always first
              final distinctPlaces = allStudents
                  .map((s) => s.place.trim())
                  .where((s) => s.isNotEmpty)
                  .toSet()
                  .toList()
                ..sort();
              final placeOptions = distinctPlaces; // UPDATED: no separate 'All' chip here

              // Update the notifiers after the current frame to avoid
              // calling setState-equivalent during build.
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                final currentStates = _statesNotifier.value;
                final sameStates = currentStates.length == stateOptions.length &&
                    List.generate(currentStates.length, (i) => currentStates[i] == stateOptions[i])
                        .every((e) => e);
                if (!sameStates) {
                  _statesNotifier.value = stateOptions;
                }
                final currentPlaces = _placesNotifier.value;
                final samePlaces = currentPlaces.length == placeOptions.length &&
                    List.generate(currentPlaces.length, (i) => currentPlaces[i] == placeOptions[i])
                        .every((e) => e);
                if (!samePlaces) {
                  _placesNotifier.value = placeOptions;
                }
              });

              final students = allStudents.where((s) {
                final matchesStatus = _selectedStatus == 'All' || s.status == _selectedStatus;
                final matchesState = _selectedState == 'All' || s.state == _selectedState; // NEW
                final matchesPlace = _selectedPlace == 'All' || s.place == _selectedPlace; // NEW
                final matchesSearch = _searchQuery.isEmpty ||
                    s.name.toLowerCase().contains(_searchQuery) ||
                    s.email.toLowerCase().contains(_searchQuery) ||
                    s.phone.toLowerCase().contains(_searchQuery) ||
                    s.state.toLowerCase().contains(_searchQuery) || // NEW
                    s.place.toLowerCase().contains(_searchQuery); // NEW
                return matchesStatus && matchesState && matchesPlace && matchesSearch; // UPDATED
              }).toList();

              if (students.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text('No students found',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 16)),
                  ),
                );
              }

              return SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, index) {
                      final student = students[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: _pSurface,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: _statusColor(student.status).withValues(alpha: 0.3)),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => StudentDetailScreen(student: student),
                              ),
                            );
                          },
                          leading: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [
                                  _pGold.withValues(alpha: 0.7),
                                  _pAccent.withValues(alpha: 0.6),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: CircleAvatar(
                              radius: 22,
                              backgroundColor: _pBackground,
                              child: Text(
                                student.name.isNotEmpty ? student.name[0].toUpperCase() : '?',
                                style: GoogleFonts.plusJakartaSans(
                                    color: _pAccent, fontWeight: FontWeight.w700),
                              ),
                            ),
                          ),
                          title: Text(
                            student.name,
                            style: GoogleFonts.plusJakartaSans(
                                color: _pTextPrimary, fontWeight: FontWeight.w700, fontSize: 16),
                          ),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              // NEW: show place/state alongside batch + phone
                              [
                                student.batchName,
                                student.phone,
                                if (student.place.isNotEmpty) student.place,
                                if (student.state.isNotEmpty) student.state,
                              ].join(' • '),
                              style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 13),
                            ),
                          ),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: _statusColor(student.status).withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              student.status,
                              style: GoogleFonts.plusJakartaSans(
                                color: _statusColor(student.status),
                                fontWeight: FontWeight.w600,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                    childCount: students.length,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}