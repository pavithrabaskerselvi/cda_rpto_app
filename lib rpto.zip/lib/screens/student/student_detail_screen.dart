import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../config/constants.dart';
import '../../models/student_model.dart';
import 'student_edit_screen.dart';
import 'student_info_tab.dart';
import 'student_documents_tab.dart';
import 'student_batch_history.dart';

class StudentDetailScreen extends StatelessWidget {
  final StudentModel student;
  const StudentDetailScreen({super.key, required this.student});

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kSurface,
        title: const Text('Delete Student', style: TextStyle(color: Colors.white)),
        content: Text('Delete ${student.name}? This cannot be undone.',
            style: const TextStyle(color: Colors.grey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () async {
              await FirebaseFirestore.instance.collection('students').doc(student.id).delete();
              if (context.mounted) {
                Navigator.pop(context); // close dialog
                Navigator.pop(context); // back to list
              }
            },
            child: const Text('Delete', style: TextStyle(color: kCoral)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: kNavy,
        appBar: AppBar(
          backgroundColor: kNavy,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(student.name, style: const TextStyle(color: Colors.white)),
          actions: [
            IconButton(
              icon: const Icon(Icons.edit, color: kTeal),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => StudentEditScreen(student: student)),
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, color: kCoral),
              onPressed: () => _confirmDelete(context),
            ),
          ],
          bottom: const TabBar(
            indicatorColor: kTeal,
            labelColor: kTeal,
            unselectedLabelColor: Colors.grey,
            tabs: [
              Tab(text: 'Info'),
              Tab(text: 'Documents'),
              Tab(text: 'Batch History'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            StudentInfoTab(student: student),
            StudentDocumentsTab(studentId: student.id),
            StudentBatchHistory(student: student),
          ],
        ),
      ),
    );
  }
}