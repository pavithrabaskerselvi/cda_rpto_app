import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/company_model.dart';
import 'company_add_screen.dart';
import 'company_detail_screen.dart';

// ---- Premium theme, scoped to this screen (matches Instructors screen) ----
const Color _pBackground = Color(0xFF05070D);
const Color _pSurface = Color(0xFF10141F);
const Color _pAccent = Color(0xFF2DD4BF);
const Color _pGold = Color(0xFFC9A24B);
const Color _pTextPrimary = Color(0xFFF5F6FA);
const Color _pTextSecondary = Color(0xFF8A93A6);
const Color _pSuccess = Color(0xFF3FCE8E);
const Color _pDanger = Color(0xFFE0685A);

class CompanyListScreen extends StatefulWidget {
  const CompanyListScreen({super.key});

  @override
  State<CompanyListScreen> createState() => _CompanyListScreenState();
}

class _CompanyListScreenState extends State<CompanyListScreen> {
  String _searchQuery = '';
  final _searchController = TextEditingController();
  String _selectedFilter = 'All';
  final List<String> _filters = ['All', 'Active', 'Inactive'];

  Stream<QuerySnapshot> _companyStream() {
    return FirebaseFirestore.instance
        .collection('companies')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _pBackground,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: _pBackground,
            pinned: true,
            expandedHeight: 130,
            elevation: 0,
            iconTheme: const IconThemeData(color: _pTextPrimary),
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              title: Text(
                'Company Details',
                style: GoogleFonts.plusJakartaSans(
                  color: _pTextPrimary,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                ),
              ),
              background: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_pAccent.withValues(alpha: 0.35), _pBackground],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: _searchController,
                style: GoogleFonts.plusJakartaSans(color: _pTextPrimary),
                onChanged: (val) => setState(() => _searchQuery = val.toLowerCase()),
                decoration: InputDecoration(
                  hintText: 'Search details...',
                  hintStyle: GoogleFonts.plusJakartaSans(color: _pTextSecondary),
                  prefixIcon: const Icon(Icons.search, color: _pTextSecondary),
                  filled: true,
                  fillColor: _pSurface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _filters.length,
                itemBuilder: (context, index) {
                  final filter = _filters[index];
                  final isSelected = _selectedFilter == filter;
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: ChoiceChip(
                      label: Text(filter),
                      selected: isSelected,
                      onSelected: (_) => setState(() => _selectedFilter = filter),
                      selectedColor: _pAccent,
                      backgroundColor: _pSurface,
                      labelStyle: GoogleFonts.plusJakartaSans(
                        color: isSelected ? _pBackground : _pTextSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(
                          color: isSelected ? _pAccent : Colors.white.withValues(alpha: 0.08),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 12)),
          StreamBuilder<QuerySnapshot>(
            stream: _companyStream(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator(color: _pAccent)),
                );
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text('No companies found',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
                  ),
                );
              }

              final allCompanies = snapshot.data!.docs
                  .map((d) => CompanyModel.fromDocument(d))
                  .toList();

              var mainCompanies = allCompanies
                  .where((c) => c.isMainCompany)
                  .where((c) => _selectedFilter == 'All' || c.status == _selectedFilter)
                  .where((c) => _searchQuery.isEmpty || c.name.toLowerCase().contains(_searchQuery))
                  .toList();

              if (mainCompanies.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text('No matching companies',
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary)),
                  ),
                );
              }

              return SliverList(
                delegate: SliverChildBuilderDelegate(
                      (context, index) {
                    final company = mainCompanies[index];
                    final branches = allCompanies
                        .where((c) => c.parentCompanyId == company.id)
                        .toList();

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildCompanyCard(company, branchCount: branches.length),
                        ...branches.asMap().entries.map((entry) {
                          final isLast = entry.key == branches.length - 1;
                          return _buildBranchRow(entry.value, isLast: isLast);
                        }),
                        const SizedBox(height: 4),
                      ],
                    );
                  },
                  childCount: mainCompanies.length,
                ),
              );
            },
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _pAccent,
        icon: Icon(Icons.add, color: _pBackground),
        label: Text(
          'Add Details',
          style: GoogleFonts.plusJakartaSans(color: _pBackground, fontWeight: FontWeight.w700),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CompanyAddScreen()),
          );
        },
      ),
    );
  }

  Widget _buildCompanyCard(CompanyModel company, {required int branchCount}) {
    final isActive = company.status == 'Active';
    final statusColor = isActive ? _pSuccess : _pDanger;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => CompanyDetailScreen(company: company)),
        );
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _pSurface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: statusColor.withValues(alpha: 0.28)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_pGold.withValues(alpha: 0.7), _pAccent.withValues(alpha: 0.5)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: CircleAvatar(
                radius: 22,
                backgroundColor: _pBackground,
                child: Text(
                  company.name.isNotEmpty ? company.name[0].toUpperCase() : '?',
                  style: GoogleFonts.plusJakartaSans(
                    color: _pAccent,
                    fontWeight: FontWeight.w700,
                    fontSize: 17,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          company.name,
                          style: GoogleFonts.plusJakartaSans(
                            color: _pTextPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: statusColor.withValues(alpha: 0.45)),
                        ),
                        child: Text(
                          company.status,
                          style: GoogleFonts.plusJakartaSans(
                            color: statusColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${company.city}, ${company.state}',
                    style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 12),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(Icons.phone_outlined, color: _pTextSecondary.withValues(alpha: 0.7), size: 14),
                      const SizedBox(width: 4),
                      Text(
                        company.contactPhone,
                        style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 11),
                      ),
                      if (branchCount > 0) ...[
                        const SizedBox(width: 12),
                        Icon(Icons.account_tree_outlined, color: _pGold.withValues(alpha: 0.85), size: 14),
                        const SizedBox(width: 4),
                        Text(
                          '$branchCount ${branchCount == 1 ? 'branch' : 'branches'}',
                          style: GoogleFonts.plusJakartaSans(
                            color: _pGold,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: _pTextSecondary.withValues(alpha: 0.6)),
          ],
        ),
      ),
    );
  }

  // Branch row, indented with a connector line so it visually nests under its company
  Widget _buildBranchRow(CompanyModel branch, {required bool isLast}) {
    final isActive = branch.status == 'Active';
    final statusColor = isActive ? _pSuccess : _pDanger;

    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 6),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 28,
              child: Column(
                children: [
                  Container(width: 2, height: 22, color: Colors.white.withValues(alpha: 0.12)),
                  Container(width: 12, height: 2, color: Colors.white.withValues(alpha: 0.12)),
                ],
              ),
            ),
            Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => CompanyDetailScreen(company: branch)),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _pSurface.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: _pGold.withValues(alpha: 0.15),
                        child: Text(
                          branch.name.isNotEmpty ? branch.name[0].toUpperCase() : '?',
                          style: GoogleFonts.plusJakartaSans(
                            color: _pGold,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              branch.name,
                              style: GoogleFonts.plusJakartaSans(
                                color: _pTextPrimary,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${branch.city}, ${branch.state}',
                              style: GoogleFonts.plusJakartaSans(color: _pTextSecondary, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          branch.status,
                          style: GoogleFonts.plusJakartaSans(
                            color: statusColor,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}