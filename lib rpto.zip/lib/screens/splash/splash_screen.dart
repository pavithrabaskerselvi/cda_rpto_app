import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// TODO: point this to wherever your app decides Admin/Instructor/Student
// routing after splash — usually an AuthGate widget in main.dart.
// import '../auth/login_screen.dart';

// NOTE: If your project's `lib/config/constants.dart` already defines
// kNavy / kTeal / kSurface, delete these locals and import that file
// instead so this screen shares the exact tokens as login/register screens.
const _kNavy = Color(0xFF050A14);
const _kSurface = Color(0xFF0F1B2E);
const _kTeal = Color(0xFF14B8A6);
const _kGreen = Color(0xFF22C55E);

// Same logo asset used on the login screen. Path must match EXACTLY what's
// registered under `flutter: assets:` in pubspec.yaml.
const _kLogoAssetPath = 'lib/assets/images/logo.webp';

class SplashScreen extends StatefulWidget {
  /// Called once the splash animation finishes. Wire this to Navigator
  /// .pushReplacement(...) to your AuthGate / LoginScreen in main.dart,
  /// e.g. onFinished: () => Navigator.pushReplacement(context,
  /// MaterialPageRoute(builder: (_) => const AuthGate())).
  final VoidCallback? onFinished;

  const SplashScreen({super.key, this.onFinished});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  // Logo + text entrance.
  late final AnimationController _entranceCtrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1000),
  )..forward();

  // Slow ambient background drift + floating logo.
  late final AnimationController _ambientCtrl = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  )..repeat(reverse: true);

  // Loading progress, 0 -> 1 once. Drives both the segmented bar and the
  // live "0% to 100%" counter.
  late final AnimationController _loadCtrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  );

  Timer? _navTimer;

  Animation<double> _stagger(double start, double end) {
    return CurvedAnimation(
      parent: _entranceCtrl,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
  }

  @override
  void initState() {
    super.initState();
    _loadCtrl.forward();
    _navTimer = Timer(const Duration(milliseconds: 2600), () {
      if (!mounted) return;
      widget.onFinished?.call();
      // Fallback if no callback was provided — replace with your real route.
      // Navigator.of(context).pushReplacement(
      //   MaterialPageRoute(builder: (_) => const LoginScreen()),
      // );
    });
  }

  @override
  void dispose() {
    _navTimer?.cancel();
    _entranceCtrl.dispose();
    _ambientCtrl.dispose();
    _loadCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kNavy,
      body: Stack(
        children: [
          _AmbientBackground(controller: _ambientCtrl),
          SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 3),
                _FadeSlideIn(
                  animation: _stagger(0.0, 0.55),
                  child: _AnimatedLogo(controller: _ambientCtrl),
                ),
                const SizedBox(height: 22),
                _FadeSlideIn(
                  animation: _stagger(0.15, 0.65),
                  child: const _TitleBlock(),
                ),
                const Spacer(flex: 3),
                _FadeSlideIn(
                  animation: _stagger(0.35, 0.85),
                  child: _LoadingStatus(controller: _loadCtrl),
                ),
                const SizedBox(height: 12),
                _FadeSlideIn(
                  animation: _stagger(0.35, 0.85),
                  child: _SegmentedLoadingBar(controller: _loadCtrl),
                ),
                const SizedBox(height: 48),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// Fade + slide-up wrapper driven by an outer stagger animation.
/// ---------------------------------------------------------------------------
class _FadeSlideIn extends StatelessWidget {
  final Animation<double> animation;
  final Widget child;

  const _FadeSlideIn({required this.animation, required this.child});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      child: child,
      builder: (context, child) {
        return Opacity(
          opacity: animation.value.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, (1 - animation.value) * 18),
            child: child,
          ),
        );
      },
    );
  }
}

/// ---------------------------------------------------------------------------
/// Deep-navy background with slow-breathing teal glow, matching
/// login_screen.dart and register_screen.dart.
/// ---------------------------------------------------------------------------
class _AmbientBackground extends StatelessWidget {
  final AnimationController controller;
  const _AmbientBackground({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final t = controller.value;
        return Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [_kNavy, _kSurface],
                ),
              ),
            ),
            Positioned(
              top: -140 + (t * 20),
              right: -110,
              child: _glow(_kTeal.withValues(alpha: 0.16), 320),
            ),
            Positioned(
              bottom: -160 - (t * 20),
              left: -120,
              child: _glow(_kTeal.withValues(alpha: 0.08), 320),
            ),
          ],
        );
      },
    );
  }

  Widget _glow(Color color, double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: color, blurRadius: 160, spreadRadius: 60)],
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// The academy mark: your CDA logo (square/circular white badge with the
/// winged emblem + "Chennai Drone Academy" wordmark) dropped into the
/// floating glow badge, same asset used on the login screen.
/// ---------------------------------------------------------------------------
class _AnimatedLogo extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedLogo({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final dy = math.sin(controller.value * math.pi) * 7;
        return Transform.translate(
          offset: Offset(0, -dy),
          child: Container(
            height: 128,
            width: 128,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              boxShadow: [
                BoxShadow(color: _kTeal.withValues(alpha: 0.5), blurRadius: 36, spreadRadius: 3),
                BoxShadow(color: Colors.black.withValues(alpha: 0.25), blurRadius: 14, offset: const Offset(0, 5)),
              ],
            ),
            padding: const EdgeInsets.all(4),
            child: ClipOval(
              child: Image.asset(
                _kLogoAssetPath,
                fit: BoxFit.cover,
                // If the asset isn't found (wrong path / not yet added),
                // gracefully fall back to the original takeoff icon so the
                // splash screen never crashes or shows a broken-image glyph.
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(Icons.flight_takeoff_rounded, size: 50, color: _kTeal);
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

/// ---------------------------------------------------------------------------
/// Wordmark set in Orbitron for a technical, HUD-like feel that fits the
/// drone-academy subject. "Chennai Drone Academy" leads; the RPTO full form
/// sits underneath as the accent line (no more "Inventory Management System"
/// placeholder text).
/// ---------------------------------------------------------------------------
class _TitleBlock extends StatelessWidget {
  const _TitleBlock();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'CHENNAI DRONE ACADEMY',
          textAlign: TextAlign.center,
          style: GoogleFonts.orbitron(
            color: Colors.white,
            fontSize: 21,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.4,
            height: 1.2,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'REMOTE PILOT TRAINING ORGANISATION',
          textAlign: TextAlign.center,
          style: GoogleFonts.orbitron(
            color: _kTeal,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 2.2,
            height: 1.4,
          ),
        ),
      ],
    );
  }
}

/// ---------------------------------------------------------------------------
/// Status row above the bar: a pulsing green "ready" dot, a status label,
/// and the live 0% -> 100% counter — all in Orbitron for that HUD feel.
/// ---------------------------------------------------------------------------
class _LoadingStatus extends StatelessWidget {
  final AnimationController controller;
  const _LoadingStatus({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final pct = (Curves.easeInOut.transform(controller.value) * 100).round();
          return Row(
            children: [
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kGreen,
                  boxShadow: [BoxShadow(color: _kGreen.withValues(alpha: 0.6), blurRadius: 8, spreadRadius: 1)],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'PRE-FLIGHT READY',
                style: GoogleFonts.orbitron(
                  color: Colors.white70,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.4,
                ),
              ),
              const Spacer(),
              Text(
                '$pct%',
                style: GoogleFonts.orbitron(
                  color: _kTeal,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.0,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// Signature element: a segmented "systems check" bar — a row of small
/// blocks that light up one by one as progress advances, instead of a
/// single solid fill. Reads like an aircraft pre-flight checklist rather
/// than a generic progress bar.
/// ---------------------------------------------------------------------------
class _SegmentedLoadingBar extends StatelessWidget {
  final AnimationController controller;
  static const int _segmentCount = 24;

  const _SegmentedLoadingBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          final progress = Curves.easeInOut.transform(controller.value);
          final litCount = (progress * _segmentCount).floor();
          return Row(
            children: List.generate(_segmentCount, (i) {
              final isLit = i < litCount;
              final isLeading = i == litCount; // segment currently "igniting"
              return Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 1.5),
                  height: 14,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    color: isLit
                        ? _kTeal
                        : isLeading
                        ? _kTeal.withValues(alpha: 0.45)
                        : Colors.white.withValues(alpha: 0.08),
                    boxShadow: isLit
                        ? [BoxShadow(color: _kTeal.withValues(alpha: 0.5), blurRadius: 6, spreadRadius: 0.5)]
                        : [],
                  ),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}