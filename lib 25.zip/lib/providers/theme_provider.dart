import 'package:flutter/material.dart';

/// App-wide light/dark toggle. Register this once in main.dart with
/// ChangeNotifierProvider and every screen that wants to react to the
/// theme just does: `context.watch<ThemeProvider>().isDark`.
class ThemeProvider extends ChangeNotifier {
  bool _isDark = true;

  bool get isDark => _isDark;

  void toggleTheme() {
    _isDark = !_isDark;
    notifyListeners();
  }

  void setDark(bool value) {
    if (_isDark == value) return;
    _isDark = value;
    notifyListeners();
  }
}
