import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../config/routes.dart';

// ---------- Design Constants (premium CDA RPTO design system) ----------
const Color _kNavy = Color(0xFFF7F8FA);
const Color _kSurface = Color(0xFFFFFFFF);
const Color _kSurfaceElevated = Color(0xFFF1F3F6);
const Color _kTeal = Color(0xFF0F9E93);
const Color _kTealGlow = Color(0xFF14B8A6);
const Color _kTextPrimary = Color(0xFF0F172A);
const Color _kTextSecondary = Color(0xFF5B6472);
const Color _kBorder = Color(0xFFE2E5EA);

class BatchListScreen extends StatelessWidget {
  const BatchListScreen({super.key});

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'ongoing':
        return _kTeal;
      case 'completed':
        return Colors.greenAccent;
      case 'upcoming':
        return Colors.amberAccent;
      default:
        return _kTextSecondary;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kNavy,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: _kNavy,
            pinned: true,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: _kTextPrimary),
              onPressed: () => Navigator.of(context).pop(),
            ),
            title: const Text(
              'BatchList',
              style: TextStyle(
                color: _kTextPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 24,
                letterSpacing: 0.2,
              ),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_kTeal, _kTealGlow],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: _kTeal.withOpacity(0.35),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.add, color: Colors.white),
                    onPressed: () {
                      Navigator.of(context).pushNamed(AppRoutes.batchAdd);
                    },
                  ),
                ),
              ),
            ],
          ),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('batches')
                .orderBy('startDate', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return SliverFillRemaining(
                  child: Center(
                    child: Text(
                      'Error loading batches: ${snapshot.error}',
                      style: const TextStyle(color: Colors.redAccent),
                    ),
                  ),
                );
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SliverFillRemaining(
                  child: Center(
                    child: CircularProgressIndicator(color: _kTeal),
                  ),
                );
              }

              final docs = snapshot.data?.docs ?? [];

              if (docs.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.groups_outlined,
                            color: _kTextSecondary, size: 52),
                        SizedBox(height: 14),
                        Text(
                          'No batches found',
                          style: TextStyle(
                            color: _kTextPrimary,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Tap + to create a new batch',
                          style: TextStyle(color: _kTextSecondary, fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                );
              }

              return SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, index) {
                      final data =
                      docs[index].data() as Map<String, dynamic>;
                      final docId = docs[index].id;

                      final batchName = data['batchName'] ?? 'Unnamed Batch';
                      final instructor = data['instructor'] ?? '-';
                      final studentCount = data['studentCount'] ?? 0;
                      final status = data['status'] ?? 'Upcoming';
                      final startDate = data['startDate'] != null
                          ? (data['startDate'] as Timestamp).toDate()
                          : null;
                      final endDate = data['endDate'] != null
                          ? (data['endDate'] as Timestamp).toDate()
                          : null;

                      return Container(
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [_kSurfaceElevated, _kSurface],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _kBorder),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.25),
                              blurRadius: 16,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(18),
                            splashColor: _kTeal.withOpacity(0.08),
                            highlightColor: _kTeal.withOpacity(0.04),
                            onTap: () {
                              Navigator.of(context).pushNamed(
                                AppRoutes.batchDetail,
                                arguments: docId,
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          batchName,
                                          style: const TextStyle(
                                            color: _kTextPrimary,
                                            fontSize: 19,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: 0.1,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 12, vertical: 6),
                                        decoration: BoxDecoration(
                                          color: _statusColor(status)
                                              .withOpacity(0.15),
                                          borderRadius:
                                          BorderRadius.circular(20),
                                          border: Border.all(
                                            color: _statusColor(status)
                                                .withOpacity(0.4),
                                            width: 1,
                                          ),
                                        ),
                                        child: Text(
                                          status,
                                          style: TextStyle(
                                            color: _statusColor(status),
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 14),
                                  Container(
                                    height: 1,
                                    color: _kBorder,
                                  ),
                                  const SizedBox(height: 14),
                                  _infoRow(Icons.person_outline,
                                      'Instructor: $instructor'),
                                  const SizedBox(height: 8),
                                  _infoRow(Icons.groups_2_outlined,
                                      'Students: $studentCount'),
                                  if (startDate != null && endDate != null) ...[
                                    const SizedBox(height: 8),
                                    _infoRow(
                                      Icons.calendar_today_outlined,
                                      '${_formatDate(startDate)} - ${_formatDate(endDate)}',
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                    childCount: docs.length,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: _kTeal, size: 17),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              color: _kTextSecondary,
              fontSize: 14.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }
}