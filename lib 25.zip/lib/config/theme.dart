import 'package:flutter/material.dart';

/// Central light/dark color set for the "premium" screens (Company,
/// Student, Drone, Instructor, Simulator...) that used to hardcode their
/// own `const Color _pBackground = ...` at the top of each file.
///
/// Usage inside a screen's build():
///   final isDark = context.watch<ThemeProvider>().isDark;
///   final c = CompanyColors.of(isDark);
///   ... Scaffold(backgroundColor: c.background, ...)
class CompanyColors {
  final Color background;
  final Color surface;
  final Color surfaceElevated;
  final Color accent; // teal
  final Color gold;
  final Color textPrimary;
  final Color textSecondary;
  final Color success;
  final Color danger;
  final Color borderSubtle;

  const CompanyColors({
    required this.background,
    required this.surface,
    required this.surfaceElevated,
    required this.accent,
    required this.gold,
    required this.textPrimary,
    required this.textSecondary,
    required this.success,
    required this.danger,
    required this.borderSubtle,
  });

  static const CompanyColors dark = CompanyColors(
    background: Color(0xFF05070D),
    surface: Color(0xFF10141F),
    surfaceElevated: Color(0xFF161B29),
    accent: Color(0xFF2DD4BF),
    gold: Color(0xFFC9A24B),
    textPrimary: Color(0xFFF5F6FA),
    textSecondary: Color(0xFF8A93A6),
    success: Color(0xFF3FCE8E),
    danger: Color(0xFFE0685A),
    borderSubtle: Colors.white,
  );

  static const CompanyColors light = CompanyColors(
    background: Color(0xFFF6F7FA),
    surface: Color(0xFFFFFFFF),
    surfaceElevated: Color(0xFFF0F1F5),
    accent: Color(0xFF0D9488),
    gold: Color(0xFFAD7C1B),
    textPrimary: Color(0xFF11151C),
    textSecondary: Color(0xFF5B6472),
    success: Color(0xFF1F9D5A),
    danger: Color(0xFFD64545),
    borderSubtle: Colors.black,
  );

  static CompanyColors of(bool isDark) => isDark ? dark : light;
}
