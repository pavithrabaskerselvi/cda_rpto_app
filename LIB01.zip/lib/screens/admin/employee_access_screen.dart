// lib/screens/admin/employee_access_screen.dart
//
// Admin screen listing every instructor/student account with controls to
// grant viewer/editor access, reject/revoke access, or delete the profile.
// Uses AppColors from config/theme.dart so it matches the rest of the app.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../config/theme.dart';
import '../../models/user_role_model.dart';
import '../../services/access_control_service.dart';

class EmployeeAccessScreen extends StatelessWidget {
  const EmployeeAccessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final adminUid = FirebaseAuth.instance.currentUser?.uid ?? '';

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Instructor Access'),
        backgroundColor: AppColors.bg,
      ),
      body: StreamBuilder<List<AppUserAccess>>(
        stream: AccessControlService.watchManagedUsers(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: AppColors.teal),
            );
          }
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Failed to load users.\n${snapshot.error}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.textSecondary),
              ),
            );
          }

          final users = snapshot.data ?? const <AppUserAccess>[];
          if (users.isEmpty) {
            return const Center(
              child: Text(
                'No instructor accounts yet.',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: users.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              return _UserCard(user: users[index], adminUid: adminUid);
            },
          );
        },
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  final AppUserAccess user;
  final String adminUid;

  const _UserCard({required this.user, required this.adminUid});

  Color get _statusColor {
    switch (user.accessStatus) {
      case AccessStatus.approved:
        return AppColors.green;
      case AccessStatus.rejected:
        return AppColors.coral;
      case AccessStatus.pending:
        return AppColors.amber;
    }
  }

  Future<void> _setLevel(BuildContext context, AccessLevel level) async {
    await AccessControlService.setAccessLevel(
      targetUid: user.uid,
      level: level,
      adminUid: adminUid,
    );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${user.name}: access set to ${accessLevelToString(level)}')),
      );
    }
  }

  Future<void> _reject(BuildContext context) async {
    await AccessControlService.rejectAccess(
      targetUid: user.uid,
      adminUid: adminUid,
    );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${user.name}: access revoked')),
      );
    }
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Delete profile?', style: TextStyle(color: AppColors.textPrimary)),
        content: Text(
          'This removes ${user.name}\'s Firestore profile. It does NOT delete '
              'their login account — do that from the Firebase console if needed.',
          style: const TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: AppColors.coral)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await AccessControlService.deleteUserProfile(user.uid);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: AppColors.blue.withOpacity(0.15),
                child: Text(
                  user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                  style: const TextStyle(color: AppColors.blue, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user.name.isEmpty ? '(no name)' : user.name,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                    Text(
                      user.email,
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  accessStatusToString(user.accessStatus).toUpperCase(),
                  style: TextStyle(color: _statusColor, fontSize: 10, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              _Chip(label: user.role.toUpperCase(), color: AppColors.purple),
              if (user.branch.isNotEmpty)
                _Chip(label: user.branch, color: AppColors.blue),
              _Chip(
                label: 'Access: ${accessLevelToString(user.accessLevel)}',
                color: AppColors.teal,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _ActionButton(
                  label: 'Viewer',
                  onTap: () => _setLevel(context, AccessLevel.viewer),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _ActionButton(
                  label: 'Editor',
                  onTap: () => _setLevel(context, AccessLevel.editor),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _ActionButton(
                  label: 'Revoke',
                  color: AppColors.coral,
                  onTap: () => _reject(context),
                ),
              ),
              const SizedBox(width: 6),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.textMuted),
                onPressed: () => _confirmDelete(context),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  const _Chip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;
  const _ActionButton({required this.label, required this.onTap, this.color = AppColors.teal});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        foregroundColor: color,
        side: BorderSide(color: color.withOpacity(0.5)),
        padding: const EdgeInsets.symmetric(vertical: 10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}