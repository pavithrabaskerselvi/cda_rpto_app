import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../config/theme.dart';
import 'aerial_fpv_student_detail_screen.dart';

const String kAerialFpvCollection = 'aerial_fpv_students';

class AerialFpvStudentListScreen extends StatefulWidget {
  final String category; // 'aerial' | 'fpv'
  const AerialFpvStudentListScreen({super.key, required this.category});

  @override
  State<AerialFpvStudentListScreen> createState() => _AerialFpvStudentListScreenState();
}

class _AerialFpvStudentListScreenState extends State<AerialFpvStudentListScreen> {
  String _query = '';

  bool get _isAerial => widget.category == 'aerial';
  Color get _color => _isAerial ? AppColors.blue : AppColors.purple;
  String get _label => _isAerial ? 'Aerial' : 'FPV';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('$_label Students'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0A2540),
        elevation: 0,
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _color,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Add Student'),
        onPressed: () => showStudentForm(context, category: widget.category),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
              decoration: InputDecoration(
                hintText: 'Search $_label students',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: _color.withValues(alpha: 0.06),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection(kAerialFpvCollection)
                  .where('category', isEqualTo: widget.category)
                  .snapshots(),
              builder: (context, snap) {
                if (snap.hasError) {
                  return Center(child: Text('Error: ${snap.error}'));
                }
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snap.data!.docs.where((d) {
                  final n = (d.data()['name'] ?? '').toString().toLowerCase();
                  final p = (d.data()['phone'] ?? '').toString().toLowerCase();
                  return _query.isEmpty || n.contains(_query) || p.contains(_query);
                }).toList()
                  ..sort((a, b) => (a.data()['name'] ?? '')
                      .toString()
                      .toLowerCase()
                      .compareTo((b.data()['name'] ?? '').toString().toLowerCase()));

                if (docs.isEmpty) {
                  return Center(
                    child: Text('No $_label students yet.\nTap "Add Student".',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Color(0xFF4A6382))),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final d = docs[i];
                    final data = d.data();
                    final name = (data['name'] ?? 'Unnamed').toString();
                    final docCount = ((data['documents'] as List?) ?? []).length;
                    return InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AerialFpvStudentDetailScreen(
                            docId: d.id,
                            category: widget.category,
                          ),
                        ),
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: _color.withValues(alpha: 0.25)),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: _color.withValues(alpha: 0.15),
                              child: Text(
                                name.isNotEmpty ? name[0].toUpperCase() : '?',
                                style: TextStyle(color: _color, fontWeight: FontWeight.w800),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(name,
                                      style: const TextStyle(
                                          color: Color(0xFF0A2540),
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15)),
                                  const SizedBox(height: 2),
                                  Text(
                                    (data['phone'] ?? '').toString().isEmpty
                                        ? 'No phone'
                                        : data['phone'].toString(),
                                    style: const TextStyle(
                                        color: Color(0xFF4A6382), fontSize: 12.5),
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              children: [
                                Icon(Icons.attach_file, size: 16, color: _color),
                                Text('$docCount',
                                    style: TextStyle(
                                        color: _color, fontWeight: FontWeight.w700)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// Add (doc == null) or edit a student. Shared by list + detail screens.
Future<void> showStudentForm(
    BuildContext context, {
      required String category,
      DocumentSnapshot<Map<String, dynamic>>? doc,
    }) async {
  final data = doc?.data() ?? {};
  final name = TextEditingController(text: data['name']?.toString() ?? '');
  final phone = TextEditingController(text: data['phone']?.toString() ?? '');
  final email = TextEditingController(text: data['email']?.toString() ?? '');
  final batch = TextEditingController(text: data['batch']?.toString() ?? '');
  final notes = TextEditingController(text: data['notes']?.toString() ?? '');
  final formKey = GlobalKey<FormState>();

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(doc == null ? 'Add Student' : 'Edit Student',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              TextFormField(
                controller: name,
                decoration: const InputDecoration(labelText: 'Name *'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              TextFormField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone'),
              ),
              TextFormField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
              TextFormField(
                controller: batch,
                decoration: const InputDecoration(labelText: 'Batch / Course'),
              ),
              TextFormField(
                controller: notes,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'Notes'),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;
                    final payload = {
                      'name': name.text.trim(),
                      'phone': phone.text.trim(),
                      'email': email.text.trim(),
                      'batch': batch.text.trim(),
                      'notes': notes.text.trim(),
                    };
                    final col = FirebaseFirestore.instance.collection(kAerialFpvCollection);
                    if (doc == null) {
                      await col.add({
                        ...payload,
                        'category': category,
                        'documents': [],
                        'createdAt': FieldValue.serverTimestamp(),
                      });
                    } else {
                      await col.doc(doc.id).update(payload);
                    }
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: Text(doc == null ? 'Save' : 'Update'),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}