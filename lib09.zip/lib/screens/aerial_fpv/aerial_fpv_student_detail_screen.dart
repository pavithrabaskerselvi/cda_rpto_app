import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../config/theme.dart';
import 'aerial_fpv_student_list_screen.dart';

class AerialFpvStudentDetailScreen extends StatelessWidget {
  final String docId;
  final String category; // 'aerial' | 'fpv'
  const AerialFpvStudentDetailScreen({
    super.key,
    required this.docId,
    required this.category,
  });

  Color get _color => category == 'aerial' ? AppColors.blue : AppColors.purple;

  DocumentReference<Map<String, dynamic>> get _ref =>
      FirebaseFirestore.instance.collection(kAerialFpvCollection).doc(docId);

  Future<void> _addLink(BuildContext context) async {
    final title = TextEditingController();
    final url = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Attach document link'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: title,
              decoration: const InputDecoration(
                  labelText: 'Title (e.g. Aadhaar, Certificate)'),
            ),
            TextField(
              controller: url,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                  labelText: 'Link (Drive / any URL)', hintText: 'https://...'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              var link = url.text.trim();
              if (link.isEmpty) return;
              if (!link.startsWith('http')) link = 'https://$link';
              await _ref.update({
                'documents': FieldValue.arrayUnion([
                  {
                    'title':
                    title.text.trim().isEmpty ? 'Document' : title.text.trim(),
                    'url': link,
                  }
                ]),
              });
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Attach'),
          ),
        ],
      ),
    );
  }

  Future<void> _openLink(BuildContext context, String url) async {
    final ok =
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Link open aagala')));
    }
  }

  Future<void> _deleteStudent(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete student?'),
        content:
        const Text('Student details + attached links ellam delete aagidum.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child:
            const Text('Delete', style: TextStyle(color: AppColors.coral)),
          ),
        ],
      ),
    );
    if (yes == true) {
      await _ref.delete();
      if (context.mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _ref.snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Scaffold(
              body: Center(child: CircularProgressIndicator()));
        }
        if (!snap.data!.exists) {
          return const Scaffold(body: Center(child: Text('Student not found')));
        }
        final doc = snap.data!;
        final d = doc.data()!;
        final docs = ((d['documents'] as List?) ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();

        Widget row(IconData icon, String label, String? value) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 18, color: _color),
              const SizedBox(width: 10),
              SizedBox(
                width: 90,
                child: Text(label,
                    style: const TextStyle(
                        color: Color(0xFF4A6382), fontSize: 13)),
              ),
              Expanded(
                child: Text(
                  (value == null || value.isEmpty) ? '-' : value,
                  style: const TextStyle(
                      color: Color(0xFF0A2540),
                      fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        );

        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            title: Text((d['name'] ?? 'Student').toString()),
            backgroundColor: Colors.white,
            foregroundColor: const Color(0xFF0A2540),
            elevation: 0,
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () =>
                    showStudentForm(context, category: category, doc: doc),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.coral),
                onPressed: () => _deleteStudent(context),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            backgroundColor: _color,
            foregroundColor: Colors.white,
            icon: const Icon(Icons.add_link),
            label: const Text('Attach Link'),
            onPressed: () => _addLink(context),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
            children: [
              // ---------- Student details ----------
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _color.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _color.withValues(alpha: 0.25)),
                ),
                child: Column(
                  children: [
                    row(Icons.person, 'Name', d['name']?.toString()),
                    row(Icons.phone, 'Phone', d['phone']?.toString()),
                    row(Icons.email_outlined, 'Email', d['email']?.toString()),
                    row(Icons.groups, 'Batch', d['batch']?.toString()),
                    row(Icons.notes, 'Notes', d['notes']?.toString()),
                    row(Icons.category, 'Category',
                        category == 'aerial' ? 'Aerial' : 'FPV'),
                  ],
                ),
              ),
              const SizedBox(height: 22),

              // ---------- Documents ----------
              Row(
                children: [
                  Container(
                    width: 4,
                    height: 16,
                    decoration: BoxDecoration(
                        color: _color, borderRadius: BorderRadius.circular(2)),
                  ),
                  const SizedBox(width: 8),
                  Text('DOCUMENTS (${docs.length})',
                      style: const TextStyle(
                          color: Color(0xFF0A2540),
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.1,
                          fontSize: 13.5)),
                ],
              ),
              const SizedBox(height: 10),
              if (docs.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Text('Links add pannala. "Attach Link" tap pannunga.',
                        style: TextStyle(color: Color(0xFF4A6382))),
                  ),
                ),
              ...docs.map((e) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _color.withValues(alpha: 0.25)),
                ),
                child: ListTile(
                  leading: Icon(Icons.description_outlined, color: _color),
                  title: Text(e['title']?.toString() ?? 'Document',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(e['url']?.toString() ?? '',
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () => _openLink(context, e['url'].toString()),
                  trailing: IconButton(
                    icon: const Icon(Icons.close, color: AppColors.coral),
                    onPressed: () => _ref.update({
                      'documents': FieldValue.arrayRemove([e]),
                    }),
                  ),
                ),
              )),
            ],
          ),
        );
      },
    );
  }
}