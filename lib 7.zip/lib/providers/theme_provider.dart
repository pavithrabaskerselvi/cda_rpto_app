import 'package:flutter/material.dart';

/// App-wide light/dark toggle. Register once in main.dart with
/// ChangeNotifierProvider. MaterialApp's themeMode reads isDarkMode so
/// Theme.of(context).brightness flips app-wide, and every screen that
/// wants to react to the theme does: context.watch<ThemeProvider>().isDarkMode
class ThemeProvider extends ChangeNotifier {
  bool _isDarkMode = true;

  bool get isDarkMode => _isDarkMode;

  /// Sets the theme directly to [value] — used by Switch widgets
  /// (onChanged gives you the new value already).
  void toggleTheme(bool value) {
    if (_isDarkMode == value) return;
    _isDarkMode = value;
    notifyListeners();
  }

  /// Flips whatever it currently is — handy for a plain tap/button.
  void flipTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }
}
