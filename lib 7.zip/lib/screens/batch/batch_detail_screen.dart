import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class BatchDetailScreen extends StatefulWidget {
  final String batchId;

  const BatchDetailScreen({super.key, required this.batchId});

  @override
  State<BatchDetailScreen> createState() => _BatchDetailScreenState();
}

class _BatchDetailScreenState extends State<BatchDetailScreen> {
  final _formKey = GlobalKey<FormState>();

  bool _isEditing = false;
  bool _isSaving = false;
  bool _isDeleting = false;

  late TextEditingController _batchNameController;
  late TextEditingController _studentCountController;

  String? _selectedInstructor;
  String? _selectedDrone;
  String _selectedStatus = 'Upcoming';
  DateTime? _startDate;
  DateTime? _endDate;

  bool _initialized = false;

  final List<String> _statusOptions = ['Upcoming', 'Ongoing', 'Completed'];

  // ---- Theme-aware colors: flip between dark/light based on current
  // Theme brightness instead of hardcoded dark-only constants. ----
  bool _isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

  Color _kNavy(BuildContext c) =>
      _isDark(c) ? const Color(0xFF05070D) : const Color(0xFFF7F8FA);
  Color _kSurface(BuildContext c) =>
      _isDark(c) ? const Color(0xFF10141F) : const Color(0xFFFFFFFF);
  Color _kTeal(BuildContext c) =>
      _isDark(c) ? const Color(0xFF2DD4BF) : const Color(0xFF0F9E93);
  Color _kTextPrimary(BuildContext c) =>
      _isDark(c) ? const Color(0xFFF5F6FA) : const Color(0xFF0F172A);
  Color _kTextSecondary(BuildContext c) =>
      _isDark(c) ? const Color(0xFF9CA3AF) : const Color(0xFF5B6472);
  Color _kBorder(BuildContext c) =>
      _isDark(c) ? const Color(0xFF1F2937) : const Color(0xFFE2E5EA);
  Color _kAmber(BuildContext c) =>
      _isDark(c) ? const Color(0xFFFFB020) : const Color(0xFFB77400);
  Color _kGreen(BuildContext c) =>
      _isDark(c) ? const Color(0xFF3FCE8E) : const Color(0xFF1F9D63);

  @override
  void initState() {
    super.initState();
    _batchNameController = TextEditingController();
    _studentCountController = TextEditingController();
  }

  @override
  void dispose() {
    _batchNameController.dispose();
    _studentCountController.dispose();
    super.dispose();
  }

  void _populateFields(Map<String, dynamic> data) {
    if (_initialized) return;
    _batchNameController.text = data['batchName'] ?? '';
    _studentCountController.text = (data['studentCount'] ?? '').toString();
    _selectedInstructor = data['instructor'];
    _selectedDrone = data['drone'];
    _selectedStatus = data['status'] ?? 'Upcoming';
    _startDate = data['startDate'] != null
        ? (data['startDate'] as Timestamp).toDate()
        : null;
    _endDate = data['endDate'] != null
        ? (data['endDate'] as Timestamp).toDate()
        : null;
    _initialized = true;
  }

  Color _statusColor(BuildContext context, String status) {
    switch (status.toLowerCase()) {
      case 'ongoing':
        return _kTeal(context);
      case 'completed':
        return _kGreen(context);
      case 'upcoming':
        return _kAmber(context);
      default:
        return _kTextSecondary(context);
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Select date';
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  Future<void> _pickDate({required bool isStart}) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart ? (_startDate ?? now) : (_endDate ?? _startDate ?? now),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 3),
      builder: (context, child) {
        final dark = _isDark(context);
        return Theme(
          data: dark
              ? ThemeData.dark().copyWith(
            colorScheme: ColorScheme.dark(
              primary: _kTeal(context),
              surface: _kSurface(context),
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: _kNavy(context),
          )
              : ThemeData.light().copyWith(
            colorScheme: ColorScheme.light(
              primary: _kTeal(context),
              surface: _kSurface(context),
              onSurface: _kTextPrimary(context),
            ),
            dialogBackgroundColor: _kNavy(context),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          if (_endDate != null && _endDate!.isBefore(_startDate!)) {
            _endDate = null;
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  Future<void> _saveChanges() async {
    if (!_formKey.currentState!.validate()) return;

    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select start and end dates'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() => _isSaving = true);

    try {
      await FirebaseFirestore.instance
          .collection('batches')
          .doc(widget.batchId)
          .update({
        'batchName': _batchNameController.text.trim(),
        'instructor': _selectedInstructor,
        'drone': _selectedDrone,
        'studentCount': int.tryParse(_studentCountController.text.trim()) ?? 0,
        'status': _selectedStatus,
        'startDate': Timestamp.fromDate(_startDate!),
        'endDate': Timestamp.fromDate(_endDate!),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        setState(() => _isEditing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Batch updated successfully'),
            backgroundColor: _kTeal(context),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating batch: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _confirmDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _kSurface(context),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Delete Batch', style: TextStyle(color: _kTextPrimary(context))),
        content: Text(
          'Are you sure you want to delete this batch? This action cannot be undone.',
          style: TextStyle(color: _kTextSecondary(context)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Cancel', style: TextStyle(color: _kTextSecondary(context))),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isDeleting = true);
      try {
        await FirebaseFirestore.instance
            .collection('batches')
            .doc(widget.batchId)
            .delete();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Batch deleted'),
              backgroundColor: _kTeal(context),
            ),
          );
          Navigator.of(context).pop();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error deleting batch: $e'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
        if (mounted) setState(() => _isDeleting = false);
      }
    }
  }

  InputDecoration _inputDecoration(BuildContext context, String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: _kTextSecondary(context)),
      prefixIcon: icon != null ? Icon(icon, color: _kTextSecondary(context)) : null,
      filled: true,
      fillColor: _kSurface(context),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _kBorder(context)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _kBorder(context)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _kTeal(context), width: 1.5),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _kBorder(context)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kNavy(context),
      appBar: AppBar(
        backgroundColor: _kNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: _kTextPrimary(context)),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'Batch Details',
          style: TextStyle(color: _kTextPrimary(context), fontWeight: FontWeight.bold, fontSize: 20),
        ),
        actions: [
          if (!_isEditing)
            IconButton(
              icon: Icon(Icons.edit_outlined, color: _kTeal(context)),
              onPressed: () => setState(() => _isEditing = true),
            ),
          IconButton(
            icon: _isDeleting
                ? const SizedBox(
              height: 18,
              width: 18,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.redAccent),
            )
                : const Icon(Icons.delete_outline, color: Colors.redAccent),
            onPressed: _isDeleting ? null : _confirmDelete,
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('batches')
            .doc(widget.batchId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading batch: ${snapshot.error}',
                style: const TextStyle(color: Colors.redAccent),
              ),
            );
          }

          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator(color: _kTeal(context)));
          }

          if (!snapshot.data!.exists) {
            return Center(
              child: Text('Batch not found', style: TextStyle(color: _kTextSecondary(context))),
            );
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          _populateFields(data);

          return Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _statusColor(context, _selectedStatus).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.circle, size: 8, color: _statusColor(context, _selectedStatus)),
                      const SizedBox(width: 6),
                      Text(
                        _selectedStatus,
                        style: TextStyle(
                          color: _statusColor(context, _selectedStatus),
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                TextFormField(
                  controller: _batchNameController,
                  enabled: _isEditing,
                  style: TextStyle(color: _kTextPrimary(context)),
                  decoration: _inputDecoration(context, 'Batch Name', icon: Icons.badge_outlined),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Batch name is required';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                _isEditing
                    ? StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('instructors')
                      .orderBy('name')
                      .snapshots(),
                  builder: (context, snap) {
                    final names = <String>[];
                    if (snap.hasData) {
                      for (final doc in snap.data!.docs) {
                        final d = doc.data() as Map<String, dynamic>;
                        if (d['name'] != null) names.add(d['name'].toString());
                      }
                    }
                    if (_selectedInstructor != null &&
                        !names.contains(_selectedInstructor)) {
                      names.add(_selectedInstructor!);
                    }
                    return DropdownButtonFormField<String>(
                      initialValue: _selectedInstructor,
                      dropdownColor: _kSurface(context),
                      style: TextStyle(color: _kTextPrimary(context)),
                      decoration:
                      _inputDecoration(context, 'Instructor', icon: Icons.person_outline),
                      items: names
                          .map((n) => DropdownMenuItem(value: n, child: Text(n)))
                          .toList(),
                      onChanged: (v) => setState(() => _selectedInstructor = v),
                      validator: (v) => v == null ? 'Please select an instructor' : null,
                    );
                  },
                )
                    : TextFormField(
                  enabled: false,
                  style: TextStyle(color: _kTextPrimary(context)),
                  decoration: _inputDecoration(context, 'Instructor', icon: Icons.person_outline)
                      .copyWith(hintText: _selectedInstructor),
                  controller: TextEditingController(text: _selectedInstructor ?? '-'),
                ),
                const SizedBox(height: 16),

                _isEditing
                    ? StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('drones')
                      .orderBy('name')
                      .snapshots(),
                  builder: (context, snap) {
                    final names = <String>[];
                    if (snap.hasData) {
                      for (final doc in snap.data!.docs) {
                        final d = doc.data() as Map<String, dynamic>;
                        if (d['name'] != null) names.add(d['name'].toString());
                      }
                    }
                    if (_selectedDrone != null && !names.contains(_selectedDrone)) {
                      names.add(_selectedDrone!);
                    }
                    return DropdownButtonFormField<String>(
                      initialValue: _selectedDrone,
                      dropdownColor: _kSurface(context),
                      style: TextStyle(color: _kTextPrimary(context)),
                      decoration: _inputDecoration(context, 'Drone', icon: Icons.flight_outlined),
                      items: names
                          .map((n) => DropdownMenuItem(value: n, child: Text(n)))
                          .toList(),
                      onChanged: (v) => setState(() => _selectedDrone = v),
                      validator: (v) => v == null ? 'Please select a drone' : null,
                    );
                  },
                )
                    : TextFormField(
                  enabled: false,
                  style: TextStyle(color: _kTextPrimary(context)),
                  controller: TextEditingController(text: _selectedDrone ?? '-'),
                  decoration: _inputDecoration(context, 'Drone', icon: Icons.flight_outlined),
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _studentCountController,
                  enabled: _isEditing,
                  keyboardType: TextInputType.number,
                  style: TextStyle(color: _kTextPrimary(context)),
                  decoration:
                  _inputDecoration(context, 'Number of Students', icon: Icons.groups_2_outlined),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Student count is required';
                    }
                    if (int.tryParse(value.trim()) == null) {
                      return 'Enter a valid number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                _isEditing
                    ? DropdownButtonFormField<String>(
                  initialValue: _selectedStatus,
                  dropdownColor: _kSurface(context),
                  style: TextStyle(color: _kTextPrimary(context)),
                  decoration: _inputDecoration(context, 'Status', icon: Icons.flag_outlined),
                  items: _statusOptions
                      .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                      .toList(),
                  onChanged: (v) => setState(() => _selectedStatus = v ?? 'Upcoming'),
                )
                    : const SizedBox.shrink(),
                if (_isEditing) const SizedBox(height: 16),

                InkWell(
                  onTap: _isEditing ? () => _pickDate(isStart: true) : null,
                  borderRadius: BorderRadius.circular(12),
                  child: InputDecorator(
                    decoration: _inputDecoration(context, 'Start Date', icon: Icons.calendar_today_outlined),
                    child: Text(
                      _formatDate(_startDate),
                      style: TextStyle(
                        color: _isEditing ? _kTextPrimary(context) : _kTextSecondary(context),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                InkWell(
                  onTap: _isEditing ? () => _pickDate(isStart: false) : null,
                  borderRadius: BorderRadius.circular(12),
                  child: InputDecorator(
                    decoration: _inputDecoration(context, 'End Date', icon: Icons.calendar_today_outlined),
                    child: Text(
                      _formatDate(_endDate),
                      style: TextStyle(
                        color: _isEditing ? _kTextPrimary(context) : _kTextSecondary(context),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 32),

                if (_isEditing)
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _isSaving
                              ? null
                              : () {
                            setState(() {
                              _isEditing = false;
                              _initialized = false;
                              _populateFields(data);
                            });
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: _kBorder(context)),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text('Cancel',
                              style: TextStyle(color: _kTextSecondary(context))),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _isSaving ? null : _saveChanges,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _kTeal(context),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: _isSaving
                              ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          )
                              : const Text(
                            'Save Changes',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}