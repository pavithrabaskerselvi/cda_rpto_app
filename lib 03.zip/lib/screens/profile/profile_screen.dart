import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../providers/profile_provider.dart';
import '../../providers/theme_provider.dart';
import '../../providers/language_provider.dart';

// ─────────────────────────────────────────────────────────────────────────
// Local isDark-aware color set for this screen. The original file used a
// static `AppColors.xxx` (from config/theme.dart) that never changed
// regardless of a "dark mode" switch — the switch just flipped a bool that
// nothing read. This local set is driven by ThemeProvider.isDark instead,
// so the Dark Mode / Light Mode toggle actually repaints the screen.
//
// TODO (app-wide, not just this screen): to make Dark/Light apply outside
// Profile too, wrap MaterialApp in main.dart with a Consumer<ThemeProvider>
// and set `theme:`/`darkTheme:`/`themeMode:` from `themeProvider.isDark` —
// see the wiring snippet shared alongside this file.
// ─────────────────────────────────────────────────────────────────────────
class _Colors {
  final bool isDark;
  const _Colors(this.isDark);

  Color get bg => isDark ? const Color(0xFF050A14) : const Color(0xFFF2F5FA);
  Color get surface => isDark ? const Color(0xFF0F1B2E) : Colors.white;
  Color get border => isDark ? const Color(0xFF1A2E50) : const Color(0xFFD8E0EC);

  Color get textPrimary => isDark ? const Color(0xFFF0F6FF) : const Color(0xFF0A1428);
  Color get textSecondary => isDark ? const Color(0xFFA0B8D0) : const Color(0xFF4A5A70);

  Color get teal => const Color(0xFF14B8A6);
  Color get blue => const Color(0xFF1E5FC8);
  Color get purple => const Color(0xFF8B5CF6);
  Color get amber => const Color(0xFFF5A623);
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isUploading = false;
  bool _pushNotifications = true;
  bool _emailNotifications = true;
  bool _biometricLogin = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ProfileProvider>().loadProfile();
    });
  }

  Future<void> _pickAndUploadPhoto(ProfileProvider provider) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
      maxWidth: 800,
    );
    if (picked == null) return;

    setState(() => _isUploading = true);
    final success = await provider.uploadProfilePhoto(File(picked.path));
    setState(() => _isUploading = false);

    if (!success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Upload failed, try again')),
      );
    }
  }

  // ── Language picker ───────────────────────────────────────────────────
  Future<void> _showLanguagePicker(_Colors c, LanguageProvider lang) async {
    const options = [
      {'code': 'en', 'label': 'English (India)'},
      {'code': 'ta', 'label': 'தமிழ் (Tamil)'},
      {'code': 'hi', 'label': 'हिन्दी (Hindi)'},
    ];

    final chosen = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: c.border,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Select Language',
                    style: TextStyle(color: c.textPrimary, fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              for (final o in options)
                RadioListTile<String>(
                  value: o['code']!,
                  groupValue: lang.code,
                  activeColor: c.teal,
                  title: Text(o['label']!, style: TextStyle(color: c.textPrimary, fontWeight: FontWeight.w600)),
                  onChanged: (val) => Navigator.pop(ctx, val),
                ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );

    if (chosen != null && chosen != lang.code) {
      await lang.setLanguage(chosen);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Language updated')),
        );
      }
    }
  }

  // ── Help & Support ────────────────────────────────────────────────────
  // TODO: swap in the real CDA IT support phone/email below.
  static const _supportPhone = '+91 00000 00000';
  static const _supportEmail = 'support@chennaidroneacademy.com';

  Future<void> _copyToClipboard(String value, String label) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$label copied to clipboard')),
      );
    }
  }

  /// Opens the dialer/mail app via [uri]. If no app on the device can
  /// handle it (e.g. no email client configured on an emulator), falls
  /// back to copying [fallbackValue] to the clipboard instead of failing
  /// silently.
  Future<void> _launchOrCopy(Uri uri, String fallbackValue, String label) async {
    try {
      final launched = await launchUrl(uri);
      if (!launched) await _copyToClipboard(fallbackValue, label);
    } catch (_) {
      await _copyToClipboard(fallbackValue, label);
    }
  }

  void _showHelpSupportDialog(_Colors c) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: c.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              Icon(Icons.support_agent, color: c.amber),
              const SizedBox(width: 10),
              Text('Help & Support', style: TextStyle(color: c.textPrimary, fontWeight: FontWeight.w800)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Reach the CDA IT team for account, app, or training queries.',
                style: TextStyle(color: c.textSecondary, fontSize: 13),
              ),
              const SizedBox(height: 16),
              _contactRow(
                c,
                icon: Icons.phone_outlined,
                value: _supportPhone,
                onTap: () => _launchOrCopy(
                  Uri(scheme: 'tel', path: _supportPhone.replaceAll(' ', '')),
                  _supportPhone,
                  'Phone number',
                ),
              ),
              const SizedBox(height: 10),
              _contactRow(
                c,
                icon: Icons.email_outlined,
                value: _supportEmail,
                onTap: () => _launchOrCopy(
                  Uri(scheme: 'mailto', path: _supportEmail),
                  _supportEmail,
                  'Email address',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Close', style: TextStyle(color: c.teal, fontWeight: FontWeight.w700)),
            ),
          ],
        );
      },
    );
  }

  Widget _contactRow(_Colors c, {required IconData icon, required String value, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: c.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: c.border),
        ),
        child: Row(
          children: [
            Icon(icon, size: 17, color: c.teal),
            const SizedBox(width: 10),
            Expanded(
              child: Text(value, style: TextStyle(color: c.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
            ),
            Icon(Icons.chevron_right_rounded, size: 17, color: c.textSecondary),
          ],
        ),
      ),
    );
  }

  // ── About App ──────────────────────────────────────────────────────────
  Future<void> _showAboutDialog(_Colors c) async {
    String version = '1.0.0';
    try {
      final info = await PackageInfo.fromPlatform();
      version = '${info.version}+${info.buildNumber}';
    } catch (_) {
      // package_info_plus not set up on this platform yet — fall back
      // to the hardcoded version below instead of failing the dialog.
    }

    if (!mounted) return;
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: c.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              Icon(Icons.info_outline, color: c.amber),
              const SizedBox(width: 10),
              Text('About App', style: TextStyle(color: c.textPrimary, fontWeight: FontWeight.w800)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'CDA RPTO — Remote Pilot Training Organisation',
                style: TextStyle(color: c.textPrimary, fontSize: 13.5, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Text(
                'Manages instructors, students, batches, drones and training '
                    'documents for Chennai Drone Academy.',
                style: TextStyle(color: c.textSecondary, fontSize: 12.5),
              ),
              const SizedBox(height: 12),
              Text('Version $version', style: TextStyle(color: c.textSecondary, fontSize: 12)),
              const SizedBox(height: 4),
              Text('© 2026 SkyLNK Unmanned Pvt. Ltd.', style: TextStyle(color: c.textSecondary, fontSize: 12)),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Close', style: TextStyle(color: c.teal, fontWeight: FontWeight.w700)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final languageProvider = context.watch<LanguageProvider>();
    final c = _Colors(themeProvider.isDark);

    return Consumer<ProfileProvider>(
      builder: (context, provider, _) {
        return Scaffold(
          backgroundColor: c.bg,
          body: SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  backgroundColor: c.bg,
                  pinned: true,
                  title: Text(
                    'Profile',
                    style: TextStyle(color: c.textPrimary, fontWeight: FontWeight.w800),
                  ),
                  iconTheme: IconThemeData(color: c.textPrimary),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildPhotoSection(c, provider),
                        const SizedBox(height: 28),
                        _sectionLabel(c, 'ACCOUNT', Icons.person_outline),
                        const SizedBox(height: 10),
                        _sectionCard(c, [
                          _tile(
                            c,
                            icon: Icons.lock_outline,
                            iconColor: c.blue,
                            title: 'Change Password',
                            subtitle: 'Sends a reset link to your email',
                            onTap: () {
                              // TODO: trigger password reset flow
                            },
                          ),
                          _tile(
                            c,
                            icon: Icons.fingerprint,
                            iconColor: c.blue,
                            title: 'Biometric Login',
                            subtitle: 'Use fingerprint / face unlock',
                            trailing: Switch(
                              value: _biometricLogin,
                              activeColor: c.teal,
                              onChanged: (val) => setState(() => _biometricLogin = val),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 22),
                        _sectionLabel(c, 'NOTIFICATIONS', Icons.notifications_none),
                        const SizedBox(height: 10),
                        _sectionCard(c, [
                          _tile(
                            c,
                            icon: Icons.campaign_outlined,
                            iconColor: c.purple,
                            title: 'Push Notifications',
                            subtitle: 'Stock alerts & drone activity',
                            trailing: Switch(
                              value: _pushNotifications,
                              activeColor: c.teal,
                              onChanged: (val) => setState(() => _pushNotifications = val),
                            ),
                          ),
                          _tile(
                            c,
                            icon: Icons.mail_outline,
                            iconColor: c.purple,
                            title: 'Email Notifications',
                            subtitle: 'Weekly inventory reports',
                            trailing: Switch(
                              value: _emailNotifications,
                              activeColor: c.teal,
                              onChanged: (val) => setState(() => _emailNotifications = val),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 22),
                        _sectionLabel(c, 'PREFERENCES', Icons.tune),
                        const SizedBox(height: 10),
                        _sectionCard(c, [
                          _tile(
                            c,
                            icon: themeProvider.isDark ? Icons.dark_mode_outlined : Icons.light_mode_outlined,
                            iconColor: c.teal,
                            title: themeProvider.isDark ? 'Dark Mode' : 'Light Mode',
                            subtitle: themeProvider.isDark ? 'Navy theme (on)' : 'Light theme (on)',
                            trailing: Switch(
                              value: themeProvider.isDark,
                              activeColor: c.teal,
                              onChanged: (val) => themeProvider.toggle(val),
                            ),
                          ),
                          _tile(
                            c,
                            icon: Icons.language,
                            iconColor: c.teal,
                            title: 'Language',
                            subtitle: languageProvider.displayName,
                            onTap: () => _showLanguagePicker(c, languageProvider),
                          ),
                        ]),
                        const SizedBox(height: 22),
                        _sectionLabel(c, 'SUPPORT', Icons.help_outline),
                        const SizedBox(height: 10),
                        _sectionCard(c, [
                          _tile(
                            c,
                            icon: Icons.support_agent,
                            iconColor: c.amber,
                            title: 'Help & Support',
                            subtitle: 'Contact the CDA IT team',
                            onTap: () => _showHelpSupportDialog(c),
                          ),
                          _tile(
                            c,
                            icon: Icons.info_outline,
                            iconColor: c.amber,
                            title: 'About App',
                            subtitle: 'RPTO Management v1.0',
                            onTap: () => _showAboutDialog(c),
                          ),
                        ]),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPhotoSection(_Colors c, ProfileProvider provider) {
    return Center(
      child: Column(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 45,
                backgroundColor: c.surface,
                backgroundImage: provider.photoUrl != null
                    ? NetworkImage(provider.photoUrl!)
                    : null,
                child: provider.photoUrl == null
                    ? Icon(Icons.person, size: 45, color: c.textSecondary)
                    : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: _isUploading ? null : () => _pickAndUploadPhoto(provider),
                  child: CircleAvatar(
                    radius: 15,
                    backgroundColor: c.teal,
                    child: _isUploading
                        ? const SizedBox(
                      width: 13,
                      height: 13,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                    )
                        : const Icon(Icons.camera_alt, size: 15, color: Colors.black),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            provider.name ?? 'Loading...',
            style: TextStyle(color: c.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
          ),
          if (provider.email != null) ...[
            const SizedBox(height: 3),
            Text(
              provider.email!,
              style: TextStyle(color: c.textSecondary, fontSize: 13),
            ),
          ],
        ],
      ),
    );
  }

  Widget _sectionLabel(_Colors c, String label, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 14, color: c.textSecondary),
        const SizedBox(width: 6),
        Text(
          label,
          style: TextStyle(
            color: c.textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.1,
          ),
        ),
      ],
    );
  }

  Widget _sectionCard(_Colors c, List<Widget> tiles) {
    return Container(
      decoration: BoxDecoration(
        color: c.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.border),
      ),
      child: Column(
        children: [
          for (int i = 0; i < tiles.length; i++) ...[
            tiles[i],
            if (i != tiles.length - 1) Divider(color: c.border, height: 1),
          ],
        ],
      ),
    );
  }

  Widget _tile(
      _Colors c, {
        required IconData icon,
        required Color iconColor,
        required String title,
        required String subtitle,
        Widget? trailing,
        VoidCallback? onTap,
      }) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: iconColor.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor, size: 19),
      ),
      title: Text(
        title,
        style: TextStyle(color: c.textPrimary, fontSize: 14.5, fontWeight: FontWeight.w700),
      ),
      subtitle: Text(
        subtitle,
        style: TextStyle(color: c.textSecondary, fontSize: 12.5),
      ),
      trailing: trailing ?? (onTap != null ? Icon(Icons.chevron_right, color: c.textSecondary, size: 20) : null),
    );
  }
}