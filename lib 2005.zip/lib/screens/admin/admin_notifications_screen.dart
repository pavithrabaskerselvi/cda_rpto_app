// lib/screens/admin/admin_notifications_screen.dart
//
// Tabbed Pending / Approved / Rejected view of access-request
// notifications, with Approve/Reject actions on pending cards.

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../config/theme.dart';
import '../../models/user_role_model.dart';
import '../../services/access_control_service.dart';

class AdminNotificationsScreen extends StatefulWidget {
  const AdminNotificationsScreen({super.key});

  @override
  State<AdminNotificationsScreen> createState() => _AdminNotificationsScreenState();
}

class _AdminNotificationsScreenState extends State<AdminNotificationsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController =
  TabController(length: 3, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Access Requests'),
        backgroundColor: AppColors.bg,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.teal,
          labelColor: AppColors.teal,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [
            Tab(text: 'Pending'),
            Tab(text: 'Approved'),
            Tab(text: 'Rejected'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _NotificationList(status: AccessStatus.pending),
          _NotificationList(status: AccessStatus.approved),
          _NotificationList(status: AccessStatus.rejected),
        ],
      ),
    );
  }
}

class _NotificationList extends StatelessWidget {
  final AccessStatus status;
  const _NotificationList({required this.status});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<AdminNotificationModel>>(
      stream: AccessControlService.watchNotifications(status: status),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: AppColors.teal),
          );
        }
        final items = snapshot.data ?? const <AdminNotificationModel>[];
        if (items.isEmpty) {
          return Center(
            child: Text(
              'No ${status.name} requests.',
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final n = items[index];
            return status == AccessStatus.pending
                ? _PendingCard(notification: n)
                : _ReadOnlyCard(notification: n);
          },
        );
      },
    );
  }
}

class _PendingCard extends StatefulWidget {
  final AdminNotificationModel notification;
  const _PendingCard({required this.notification});

  @override
  State<_PendingCard> createState() => _PendingCardState();
}

class _PendingCardState extends State<_PendingCard> {
  bool _busy = false;
  AccessLevel _grantLevel = AccessLevel.viewer;

  Future<void> _resolve(bool approve) async {
    final adminUid = FirebaseAuth.instance.currentUser?.uid;
    if (adminUid == null) return;
    setState(() => _busy = true);
    try {
      await AccessControlService.resolveNotification(
        notification: widget.notification,
        approve: approve,
        grantedLevel: _grantLevel,
        adminUid: adminUid,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(approve
                ? '${widget.notification.userName} approved (${accessLevelToString(_grantLevel)})'
                : '${widget.notification.userName} rejected'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final n = widget.notification;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.amber.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(n.userName.isEmpty ? n.userEmail : n.userName,
              style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(n.message, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(height: 10),
          Row(
            children: [
              const Text('Grant:', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              const SizedBox(width: 8),
              DropdownButton<AccessLevel>(
                value: _grantLevel,
                dropdownColor: AppColors.surface,
                style: const TextStyle(color: AppColors.textPrimary),
                underline: const SizedBox.shrink(),
                items: const [
                  DropdownMenuItem(value: AccessLevel.viewer, child: Text('Viewer')),
                  DropdownMenuItem(value: AccessLevel.editor, child: Text('Editor')),
                ],
                onChanged: _busy
                    ? null
                    : (v) => setState(() => _grantLevel = v ?? AccessLevel.viewer),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _busy ? null : () => _resolve(true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.green,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Approve'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: _busy ? null : () => _resolve(false),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.coral,
                    side: const BorderSide(color: AppColors.coral),
                  ),
                  child: const Text('Reject'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ReadOnlyCard extends StatelessWidget {
  final AdminNotificationModel notification;
  const _ReadOnlyCard({required this.notification});

  @override
  Widget build(BuildContext context) {
    final color = notification.status == AccessStatus.approved
        ? AppColors.green
        : AppColors.coral;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(
            notification.status == AccessStatus.approved
                ? Icons.check_circle_outline
                : Icons.cancel_outlined,
            color: color,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  notification.userName.isEmpty
                      ? notification.userEmail
                      : notification.userName,
                  style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600),
                ),
                Text(notification.message,
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
