// lib/screens/admin/activity_feed_screen.dart
//
// Live "what is everyone doing" feed for the admin. Reads the
// activity_logs collection in real time (StreamBuilder, not a one-time
// fetch), with tabs to filter by who did it.
//
// Only 'login' and admin-approval actions are logged out of the box.
// To make other actions (batch created, student added, drone added,
// vault upload, etc.) show up here too, call
// AccessControlService.logAction(...) from wherever that action
// happens — see the example in access_control_service.dart's doc
// comment, and INTEGRATION.md for concrete call sites in this app.

import 'package:flutter/material.dart';

import '../../config/theme.dart';
import '../../models/user_role_model.dart';
import '../../services/access_control_service.dart';

class ActivityFeedScreen extends StatefulWidget {
  const ActivityFeedScreen({super.key});

  @override
  State<ActivityFeedScreen> createState() => _ActivityFeedScreenState();
}

class _ActivityFeedScreenState extends State<ActivityFeedScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 4, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Live Activity'),
        backgroundColor: AppColors.bg,
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: AppColors.teal,
          labelColor: AppColors.teal,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [
            Tab(text: 'All'),
            Tab(text: 'Admin'),
            Tab(text: 'Instructor'),
            Tab(text: 'Student'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _ActivityList(role: null),
          _ActivityList(role: 'admin'),
          _ActivityList(role: 'instructor'),
          _ActivityList(role: 'student'),
        ],
      ),
    );
  }
}

class _ActivityList extends StatelessWidget {
  /// null = all roles (uses watchActivity). Otherwise filters to that
  /// role via watchActivityByRole.
  final String? role;
  const _ActivityList({required this.role});

  @override
  Widget build(BuildContext context) {
    final stream = role == null
        ? AccessControlService.watchActivity()
        : AccessControlService.watchActivityByRole(role: role!);

    return StreamBuilder<List<ActivityLogModel>>(
      stream: stream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: AppColors.teal),
          );
        }
        if (snapshot.hasError) {
          return Center(
            child: Text(
              'Failed to load activity.\n${snapshot.error}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          );
        }

        final logs = snapshot.data ?? const <ActivityLogModel>[];
        if (logs.isEmpty) {
          return const Center(
            child: Text('No activity yet.', style: TextStyle(color: AppColors.textSecondary)),
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: logs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) => _ActivityTile(log: logs[index]),
        );
      },
    );
  }
}

class _ActivityTile extends StatelessWidget {
  final ActivityLogModel log;
  const _ActivityTile({required this.log});

  ({IconData icon, Color color}) get _style {
    switch (log.action) {
      case 'login':
        return (icon: Icons.login_rounded, color: AppColors.teal);
      case 'access_updated':
        return (icon: Icons.verified_user_outlined, color: AppColors.green);
      case 'access_rejected':
        return (icon: Icons.person_off_outlined, color: AppColors.coral);
      default:
        return (icon: Icons.bolt_rounded, color: AppColors.blue);
    }
  }

  Color get _roleColor {
    switch (log.userRole) {
      case 'admin':
        return AppColors.purple;
      case 'instructor':
        return AppColors.blue;
      case 'student':
        return AppColors.teal;
      default:
        return AppColors.textMuted;
    }
  }

  String _timeAgo(DateTime? time) {
    if (time == null) return '';
    final diff = DateTime.now().difference(time);
    if (diff.inSeconds < 60) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${time.day}/${time.month}/${time.year}';
  }

  @override
  Widget build(BuildContext context) {
    final s = _style;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: s.color.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(s.icon, color: s.color, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        log.userName.isEmpty ? 'Unknown user' : log.userName,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w700,
                          fontSize: 13.5,
                        ),
                      ),
                    ),
                    if (log.userRole.isNotEmpty) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _roleColor.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          log.userRole.toUpperCase(),
                          style: TextStyle(color: _roleColor, fontSize: 9, fontWeight: FontWeight.w800),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  log.detail.isEmpty ? log.action : log.detail,
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _timeAgo(log.createdAt),
            style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
          ),
        ],
      ),
    );
  }
}
